package bgu.spl.mics;

import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;

/**
 * The {@link MessageBusImpl class is the implementation of the MessageBus interface.
 * Write your implementation here!
 * Only private fields and methods can be added to this class.
 */
public class MessageBusImpl implements MessageBus {
	private static MessageBusImpl instance = null;
	private final Map<Class<?>, Queue<MicroService>> eventSubscribers = new ConcurrentHashMap<>();
	private final Map<Class<?>, Queue<MicroService>> broadcastSubscribers = new ConcurrentHashMap<>();
	private final ConcurrentHashMap<Event<?>, Future<?>> eventAndFuture = new ConcurrentHashMap<>();
	private final ConcurrentHashMap<MicroService, Queue<Message>> MSQueues = new ConcurrentHashMap<>();



	@Override
	public <T> void subscribeEvent(Class<? extends Event<T>> type, MicroService m) {
		synchronized (eventSubscribers){
			eventSubscribers.computeIfAbsent(type, k -> new LinkedList<>()).add(m);
		}
	}

	@Override
	public void subscribeBroadcast(Class<? extends Broadcast> type, MicroService m) {
		synchronized (broadcastSubscribers){
			broadcastSubscribers.computeIfAbsent(type, k -> new LinkedList<>()).add(m);
		}

	}

	@Override
	public <T> void complete(Event<T> e, T result) {
		Future<T> future= (Future<T>) eventAndFuture.get(e);
		future.resolve(result);



	}

	@Override
	public void sendBroadcast(Broadcast b) {
		Class<? extends Broadcast> broadcastType= b.getClass();
		synchronized (broadcastSubscribers){
			Queue<MicroService> subscribers= broadcastSubscribers.get(broadcastType);
			if (subscribers!=null){
				for(MicroService m: subscribers ){
					MSQueues.get(m).add(b);
				}
			}
		}
	}

	
	@Override
	public <T> Future<T> sendEvent(Event<T> e) {
		Class<? extends Event<T>> eventType= (Class<? extends Event<T>>) e.getClass();
		synchronized (eventSubscribers){
			Queue<MicroService> qe= eventSubscribers.get(eventType);
			if(qe==null|| qe.isEmpty()) {
				return null;
			}
			MicroService ms= qe.poll();
			qe.add(ms);

			Queue<Message> qm= MSQueues.get(ms);
			//maybe need to check if qm=null
			qm.add(e);

			Future<T> future= new Future<>();
			eventAndFuture.put(e, future);

			return future;
		}
	}



	@Override
	public void register(MicroService m) {
		// TODO Auto-generated method stub

	}

	@Override
	public void unregister(MicroService m) {
		// TODO Auto-generated method stub

	}

	@Override
	public Message awaitMessage(MicroService m) throws InterruptedException {
		// TODO Auto-generated method stub
		return null;
	}

	public static MessageBusImpl getInstance() {
		if (instance == null) {
			synchronized (MessageBusImpl.class) {
				if (instance == null) {
					instance = new MessageBusImpl();
				}
			}
		}
		return instance;
	}

	

}
