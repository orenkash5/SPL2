package bgu.spl.mics;

import bgu.spl.mics.application.objects.Camera;
import bgu.spl.mics.application.objects.DetectedObject;
import bgu.spl.mics.application.objects.StampedDetectedObjects;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

public class CameraTestJava {
    private Camera camera;
    private List<StampedDetectedObjects> stampedDetectedObjects;

    @BeforeEach
    public void setUp() {
        stampedDetectedObjects = new ArrayList<>();
        List<DetectedObject> detectedObjects1 = new ArrayList<>();
        List<DetectedObject> detectedObjects2 = new ArrayList<>();
        detectedObjects1.add(new DetectedObject("1", "wall"));
        detectedObjects2.add(new DetectedObject("2", "chair"));
        stampedDetectedObjects.add(new StampedDetectedObjects(1, detectedObjects1));
        stampedDetectedObjects.add(new StampedDetectedObjects(2, detectedObjects2));
        this.camera = new Camera(1, 1, stampedDetectedObjects);
    }

    @Test
    public void testGetDetectedObjects() {
        List<StampedDetectedObjects> expected = stampedDetectedObjects;
        List<StampedDetectedObjects> actual = camera.getDetectedObjectList();
        assertEquals(expected, actual);
    }

    @Test
    public void testGetDetectedObjectsEmpty() {
        Camera emptyCamera = new Camera(2, 5, new ArrayList<>());
        assertEquals(0, emptyCamera.getDetectedObjectList().size());
    }

    @Test
    public void testSetLastObjects() {
        assertNull(camera.getLastDetectedObjects());

        StampedDetectedObjects newLast = stampedDetectedObjects.get(1);
        camera.setLastDetectedObjects(newLast);
        assertEquals(camera.getLastDetectedObjects(), newLast);
    }
}
