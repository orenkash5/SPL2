package bgu.spl.mics;

import bgu.spl.mics.application.messages.TrackedObjectsEvent;
import bgu.spl.mics.application.objects.*;
import bgu.spl.mics.application.services.FusionSlamService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class FusionSlamServiceTest {
    private FusionSlam fusionSlam;
    private FusionSlamService fusionSlamService;

    @BeforeEach
    public void setUp() {
        fusionSlam = FusionSlam.getInstance();
        fusionSlamService = new FusionSlamService(fusionSlam, 2, 20, new CountDownLatch(1));
    }

    @Test
    public void testTransformToGlobal() {
        Pose robotPose = new Pose(3, 4, 90, 1);
        List<CloudPoint> localCoordinates = new ArrayList<>();
        localCoordinates.add(new CloudPoint(1, 0)); // Local coordinates (1, 0)
        localCoordinates.add(new CloudPoint(0, 2)); // Local coordinates (0, 2)

        List<CloudPoint> globalCoordinates = fusionSlamService.transformToGlobal(localCoordinates, robotPose);

        assertEquals(3, globalCoordinates.get(0).getX(), 0.01); // Transformed (1,0) -> (3,5)
        assertEquals(5, globalCoordinates.get(0).getY(), 0.01);

        assertEquals(1, globalCoordinates.get(1).getX(), 0.01); // Transformed (0,2) -> (1,4)
        assertEquals(4, globalCoordinates.get(1).getY(), 0.01);
    }

    @Test
    public void testHandleTrackedObjects() {
        Pose robotPose = new Pose(3, 4, 90, 1);
        fusionSlam.addPose(robotPose);

        List<TrackedObject> trackedObjects = new ArrayList<>();
        List<CloudPoint> localCoordinates = new ArrayList<>();
        localCoordinates.add(new CloudPoint(1, 0));
        trackedObjects.add(new TrackedObject("Wall_1", 1, "Wall", localCoordinates));

        TrackedObjectsEvent event = new TrackedObjectsEvent(trackedObjects, 1);
        fusionSlamService.handleTrackedObjects(event);

        LandMark landmark = fusionSlam.findLandMark("Wall_1");
        assertNotNull(landmark);
        assertEquals(1, landmark.getCoordinates().size());
        assertEquals(3, landmark.getCoordinates().get(0).getX(), 0.01);
        assertEquals(5, landmark.getCoordinates().get(0).getY(), 0.01);
    }
}
