package bgu.spl.mics.application.objects;

import com.google.gson.*;
import com.google.gson.reflect.TypeToken;

import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

/**
 * LiDarDataBase is a singleton class responsible for managing LiDAR data.
 * It provides access to cloud point data and other relevant information for tracked objects.
 */
public class LiDarDataBase {
    private static LiDarDataBase instance = null;
    private List<StampedCloudPoints> cloudPoints;

    /**
     * Returns the singleton instance of LiDarDataBase.
     *
     * @param filePath The path to the LiDAR data file.
     * @return The singleton instance of LiDarDataBase.
     */
    public static LiDarDataBase getInstance(String filePath) {
        if (instance==null){
            synchronized (LiDarDataBase.class){
                if (instance==null){
                    instance = new LiDarDataBase();
                    instance.loadDataFromFile(filePath);
                }
            }
        }
        return instance;
    }

    public void loadDataFromFile(String filepath){
        Gson gson = new Gson();
        try (FileReader reader = new FileReader(filepath)) {
            JsonArray jsonArray = JsonParser.parseReader(reader).getAsJsonArray();
            List<StampedCloudPoints> stampedCloudPointsList = new ArrayList<>();
            for (JsonElement element : jsonArray) {
                JsonObject jsonObject = element.getAsJsonObject();
                int time = jsonObject.get("time").getAsInt();
                String id = jsonObject.get("id").getAsString();
                JsonArray cloudPointsArray = jsonObject.get("cloudPoints").getAsJsonArray();
                List<CloudPoint> points = new ArrayList<>();
                for (JsonElement pointElement : cloudPointsArray) {
                    JsonArray pointArray = pointElement.getAsJsonArray();
                    double x = pointArray.get(0).getAsDouble();
                    double y = pointArray.get(1).getAsDouble();
                    //double z = pointArray.get(2).getAsDouble();
                    //points.add(new CloudPoint(x, y, z));
                    points.add(new CloudPoint(x, y));
                }
                StampedCloudPoints stampedCloudPoints = new StampedCloudPoints(id, time, points);
                stampedCloudPointsList.add(stampedCloudPoints);
            }
            this.cloudPoints= stampedCloudPointsList;
        }
        catch (IOException e) {
            System.err.println("JSON IO Error: " + e.getMessage());

        } catch (JsonSyntaxException e) {
            System.err.println("JSON Syntax Error: " + e.getMessage());
        }
    }


//    public void loadDataFromFile(String filePath){
//        objectMapper = new ObjectMapper();
//        try{
//            List<LiDarObject> liDarObjects = objectMapper.readValue(new File(filePath), objectMapper.getTypeFactory().constructCollectionType(List.class, LiDarObject.class));
//            for (LiDarObject liDarObject : liDarObjects){
//                LiDarData cloudData = new LiDarData(liDarObject.getPoints());
//                dataBase.put(liDarObject.getId(), cloudData);
//            }
//        }
//        catch (IOException e){
//            e.printStackTrace();
//
//    }

    public List<StampedCloudPoints> getCloudPoints() {
        return cloudPoints;
    }
    public int getTimeOfLastTrack() {
        return cloudPoints.get(cloudPoints.size() - 1).getTime();
    }


//    public void setCloudPoints(List<StampedCloudPoints> cloudPoints) {
//        this.cloudPoints = cloudPoints;
//    }

}
