package bgu.spl.mics.application.services;

import bgu.spl.mics.MicroService;
import bgu.spl.mics.application.messages.*;
import bgu.spl.mics.application.objects.*;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * FusionSlamService integrates data from multiple sensors to build and update
 * the robot's global map.
 * <p>
 * This service receives TrackedObjectsEvents from LiDAR workers and PoseEvents from the PoseService,
 * transforming and updating the map with new landmarks.
 */
public class FusionSlamService extends MicroService {
    private FusionSlam fusionSlam;
    private int currentTime;
    private final StatisticalFolder statisticalFolder;
    int numberOfSensors;
    int numberOfTerminatedSensors;
    int duration;


    /**
     * Constructor for FusionSlamService.
     *
     * @param fusionSlam The FusionSLAM object responsible for managing the global map.
     */
    public FusionSlamService(FusionSlam fusionSlam, int numberOfSensors, int duration) {
        super("FusionSlamService");
        // TODO Implement this
        this.fusionSlam = FusionSlam.getInstance();
        this.currentTime = 0;
        statisticalFolder = StatisticalFolder.getInstance();
        this.numberOfSensors = numberOfSensors;
        numberOfTerminatedSensors = 0;
        this.duration = duration;

    }

    /**
     * Initializes the FusionSlamService.
     * Registers the service to handle TrackedObjectsEvents, PoseEvents, and TickBroadcasts,
     * and sets up callbacks for updating the global map.
     */
    @Override
    protected void initialize() {
        // TODO Implement this
        subscribeBroadcast(TickBroadcast.class, this::handleTick);
        subscribeEvent(TrackedObjectsEvent.class, this::handleTrackedObjects);
        subscribeEvent(PoseEvent.class, this::handlePose);
        subscribeBroadcast(TerminatedBroadcast.class, b -> {
            numberOfTerminatedSensors++;
            if (numberOfTerminatedSensors == numberOfSensors | currentTime == duration) {
                //output File
                writeOutputFile("output_file.json");
                terminate();
            }

        });
        subscribeBroadcast(CrashedBroadcast.class, b -> {
            //output Error File
            String errorDescription = b.getError();
            String faultySensor = b.getFaultySensor();
            writeErrorFile("error_output.json", errorDescription, faultySensor);

            terminate();
        });
    }


    private void handleTick(TickBroadcast tick) {
        currentTime = tick.getCurrentTick();
    }

    private void handleTrackedObjects(TrackedObjectsEvent event) {
        // TODO Implement this
        List<TrackedObject> trackedObjects = event.getTrackedObjects();
        Pose currentPose = fusionSlam.getCurrentPose(event.getTime());
        double xRobot = currentPose.getX();
        double yRobot = currentPose.getY();
        double yawRad = Math.toRadians(currentPose.getYaw());
        double cosTheta = Math.cos(yawRad);
        double sinTheta = Math.sin(yawRad);
        for (TrackedObject trackedObject : trackedObjects) {
            List<CloudPoint> localCoordinates = trackedObject.getCoordinates();
            List<CloudPoint> globalCoordinates = new ArrayList<>();
            for (CloudPoint cloudPoint : localCoordinates) {
                double xLocal = cloudPoint.getX();
                double yLocal = cloudPoint.getY();
                double xGlobal = cosTheta * xLocal - sinTheta * yLocal + xRobot;
                double yGlobal = sinTheta * xLocal + cosTheta * yLocal + yRobot;
                globalCoordinates.add(new CloudPoint(xGlobal, yGlobal));
            }
            LandMark landMark = fusionSlam.findLandMark(trackedObject.getID());
            if (landMark == null) {
                LandMark newLandMark = new LandMark(trackedObject.getID(), "object " + trackedObject.getID(), globalCoordinates);
                fusionSlam.addLandmark(newLandMark);
                statisticalFolder.incrementNumLandmarks(1);
            } else {
                List<CloudPoint> pointsToUpdate = landMark.getCoordinates();
                pointsToUpdate.addAll(globalCoordinates);
                landMark.setCoordinates(pointsToUpdate);
            }
        }


    }

    public void handlePose(PoseEvent event) {
        Pose pose = event.getPose();
        fusionSlam.addPose(pose);
    }

    private void writeErrorFile(String path, String errorDescription, String faultySensor) {
        try (FileWriter writer = new FileWriter(path)) {
            Gson gson = new Gson();
            JsonObject errorDetails = new JsonObject();
            errorDetails.addProperty("error", errorDescription);
            errorDetails.addProperty("faultySensor", faultySensor);
            //TODO: print error, faultySensor to errorDetails
            JsonObject lastCamerasFrame = new JsonObject();
            for (CameraService cameraService : ServiceTracker.getInstance().getCameraServices()) {
                StampedDetectedObjects lastFrame = cameraService.getCamera().getLastDetectedObjects();
                if (lastFrame != null) {
                    JsonObject cameraFrameJson = new JsonObject();
                    cameraFrameJson.addProperty("time", lastFrame.getTime());
                    JsonArray detectedObjectsJson = new JsonArray();
                    for (DetectedObject detectedObject : lastFrame.getDetectedObjects()) {
                        JsonObject detectedObjectJson = new JsonObject();
                        detectedObjectJson.addProperty("id", detectedObject.getId());
                        detectedObjectJson.addProperty("description", detectedObject.getDescription());
                        detectedObjectsJson.add(detectedObjectJson);
                    }
                    cameraFrameJson.add("detectedObjects", detectedObjectsJson);
                    lastCamerasFrame.add("Camera" + cameraService.getCamera().getID(), cameraFrameJson);
                }
            }
            errorDetails.add("lastCamerasFrame", lastCamerasFrame);

            JsonObject lastLiDarWorkerTrackersFrame = new JsonObject();
            for (LiDarService liDarService : ServiceTracker.getInstance().getLiDarServices()) {
                List<TrackedObject> lastTrackedObjects = liDarService.getWorker().getLastTrackedObjects();
                if (lastTrackedObjects != null) {
                    JsonArray trackedObjectsJson = new JsonArray();
                    for (TrackedObject trackedObject : lastTrackedObjects) {
                        JsonObject trackedObjectJson = new JsonObject();
                        trackedObjectJson.addProperty("id", trackedObject.getID());
                        trackedObjectJson.addProperty("time", trackedObject.getTime());
                        trackedObjectJson.addProperty("description", trackedObject.getDescription());
                        JsonArray coordinatesJson = new JsonArray();
                        for (CloudPoint point : trackedObject.getCoordinates()) {
                            JsonObject pointJson = new JsonObject();
                            pointJson.addProperty("x", point.getX());
                            pointJson.addProperty("y", point.getY());
                            coordinatesJson.add(pointJson);
                        }
                        trackedObjectJson.add("coordinates", coordinatesJson);
                        trackedObjectsJson.add(trackedObjectJson);
                    }
                    lastLiDarWorkerTrackersFrame.add("LiDarWorkerTracker" + liDarService.getWorker().getId(), trackedObjectsJson);
                }
            }
            errorDetails.add("lastLiDarWorkerTrackersFrame", lastLiDarWorkerTrackersFrame);

            JsonArray posesJson = new JsonArray();
            for (Pose pose : fusionSlam.getPosesUpToTick(currentTime)) {
                JsonObject poseJson = new JsonObject();
                poseJson.addProperty("time", pose.getTime());
                poseJson.addProperty("x", pose.getX());
                poseJson.addProperty("y", pose.getY());
                poseJson.addProperty("yaw", pose.getYaw());
                posesJson.add(poseJson);
            }
            errorDetails.add("poses", posesJson);

            JsonObject statisticsJson = new JsonObject();
            statisticsJson.addProperty("systemRuntime", currentTime);
            statisticsJson.addProperty("numDetectedObjects", statisticalFolder.getNumDetectedObjects());
            statisticsJson.addProperty("numTrackedObjects", statisticalFolder.getNumTrackedObjects());
            statisticsJson.addProperty("numLandmarks", statisticalFolder.getNumLandmarks());

            JsonObject landmarksJson = new JsonObject();
            for (LandMark landMark : fusionSlam.getLandmarks()) {
                JsonObject landmarkJson = new JsonObject();
                landmarkJson.addProperty("id", landMark.getID());
                landmarkJson.addProperty("description", landMark.getDescription());
                JsonArray coordinatesJson = new JsonArray();
                for (CloudPoint point : landMark.getCoordinates()) {
                    JsonObject pointJson = new JsonObject();
                    pointJson.addProperty("x", point.getX());
                    pointJson.addProperty("y", point.getY());
                    coordinatesJson.add(pointJson);
                }
                landmarkJson.add("coordinates", coordinatesJson);
                landmarksJson.add(landMark.getID(), landmarkJson);
            }
            statisticsJson.add("landMarks", landmarksJson);
            errorDetails.add("statistics", statisticsJson);

            gson.toJson(errorDetails, writer);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void writeOutputFile(String path) {
        try (FileWriter writer = new FileWriter(path)) {
            Gson gson = new Gson();

            JsonObject statistics = new JsonObject();
            statistics.addProperty("systemRuntime", duration);
            statistics.addProperty("numDetectedObjects", statisticalFolder.getNumDetectedObjects());
            statistics.addProperty("numTrackedObjects", statisticalFolder.getNumTrackedObjects());
            statistics.addProperty("numLandmarks", statisticalFolder.getNumLandmarks());

            JsonArray landmarks = new JsonArray();
            for (LandMark landMark : fusionSlam.getLandmarks()) {
                JsonObject landmarkJson = new JsonObject();
                landmarkJson.addProperty("id", landMark.getID());
                landmarkJson.addProperty("description", landMark.getDescription());
                JsonArray coordinates = new JsonArray();
                for (CloudPoint point : landMark.getCoordinates()) {
                    JsonObject pointJson = new JsonObject();
                    pointJson.addProperty("x", point.getX());
                    pointJson.addProperty("y", point.getY());
                    coordinates.add(pointJson);
                }
                landmarkJson.add("coordinates", coordinates);
                landmarks.add(landmarkJson);
            }
            JsonObject output = new JsonObject();
            output.add("statistics", statistics);
            output.add("landmarks", landmarks);

            gson.toJson(output, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}


