package bgu.spl.mics.application.objects;

import bgu.spl.mics.application.services.CameraService;
import bgu.spl.mics.application.services.LiDarService;
import java.security.Provider;
import java.util.ArrayList;
import java.util.List;

public class ServiceTracker {
    private static ServiceTracker instance;
    private final List<CameraService> cameraServices;
    private final List<LiDarService> lidarServices;

    private ServiceTracker() {
        cameraServices = new ArrayList<CameraService>();
        lidarServices = new ArrayList<LiDarService>();
        /*
        cameraServices = Collections.synchronizedList(new ArrayList<>());
        lidarServices = Collections.synchronizedList(new ArrayList<>());
         */
    }
    public static synchronized ServiceTracker getInstance() {
        if (instance == null) {
            instance = new ServiceTracker();
        }
        return instance;
    }
    public void registerCameraServices(List<CameraService> services) {
        cameraServices.addAll(services);
    }
    public void registerLiDarServices(List<LiDarService> services) {
        lidarServices.addAll(services);
    }
    public List<CameraService> getCameraServices() {
        return cameraServices;
    }

    public List<LiDarService> getLiDarServices() {
        return lidarServices;
    }


}
