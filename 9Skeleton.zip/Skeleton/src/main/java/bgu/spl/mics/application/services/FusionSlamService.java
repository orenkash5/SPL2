package bgu.spl.mics.application.services;

import bgu.spl.mics.MicroService;
import bgu.spl.mics.application.messages.*;
import bgu.spl.mics.application.objects.*;

import java.util.ArrayList;
import java.util.List;

/**
 * FusionSlamService integrates data from multiple sensors to build and update
 * the robot's global map.
 * <p>
 * This service receives TrackedObjectsEvents from LiDAR workers and PoseEvents from the PoseService,
 * transforming and updating the map with new landmarks.
 */
public class FusionSlamService extends MicroService {
    private FusionSlam fusionSlam;
    private int currentTime;
    private final StatisticalFolder statisticalFolder;
    int numberOfSensors;
    int numberOfTerminatedSensors;
    int duration;


    /**
     * Constructor for FusionSlamService.
     *
     * @param fusionSlam The FusionSLAM object responsible for managing the global map.
     */
    public FusionSlamService(FusionSlam fusionSlam, int numberOfSensors, int duration) {
        super("FusionSlamService");
        // TODO Implement this
        this.fusionSlam = FusionSlam.getInstance();
        this.currentTime = 0;
        statisticalFolder = StatisticalFolder.getInstance();
        this.numberOfSensors= numberOfSensors;
        numberOfTerminatedSensors=0;
        this.duration=duration;

    }

    /**
     * Initializes the FusionSlamService.
     * Registers the service to handle TrackedObjectsEvents, PoseEvents, and TickBroadcasts,
     * and sets up callbacks for updating the global map.
     */
    @Override
    protected void initialize() {
        // TODO Implement this
        subscribeBroadcast(TickBroadcast.class, this::handleTick);
        subscribeEvent(TrackedObjectsEvent.class, this::handleTrackedObjects);
        subscribeEvent(PoseEvent.class, this::handlePose);
        subscribeBroadcast(TerminatedBroadcast.class,  b-> {
            numberOfTerminatedSensors++;
            if (numberOfTerminatedSensors == numberOfSensors | currentTime==duration ) {
                //output File

                terminate();
            }


        });
        subscribeBroadcast(CrashedBroadcast.class, b -> {
            //output Error File

            terminate();
        });
    }

    private void handleTick(TickBroadcast tick) {
        currentTime = tick.getCurrentTick();
    }

    private void handleTrackedObjects(TrackedObjectsEvent event) {
        // TODO Implement this
        List<TrackedObject> trackedObjects = event.getTrackedObjects();
        Pose currentPose = fusionSlam.getCurrentPose(event.getTime());
        double xRobot = currentPose.getX();
        double yRobot = currentPose.getY();
        double yawRad = Math.toRadians(currentPose.getYaw());
        double cosTheta = Math.cos(yawRad);
        double sinTheta = Math.sin(yawRad);
        for (TrackedObject trackedObject : trackedObjects) {
            List<CloudPoint> localCoordinates = trackedObject.getCoordinates();
            List<CloudPoint> globalCoordinates = new ArrayList<>();
            for (CloudPoint cloudPoint : localCoordinates) {
                double xLocal = cloudPoint.getX();
                double yLocal = cloudPoint.getY();
                double xGlobal = cosTheta * xLocal - sinTheta * yLocal + xRobot;
                double yGlobal = sinTheta * xLocal + cosTheta * yLocal + yRobot;
                globalCoordinates.add(new CloudPoint(xGlobal, yGlobal));
            }
            LandMark landMark = fusionSlam.findLandMark(trackedObject.getID());
            if (landMark == null) {
                LandMark newLandMark = new LandMark(trackedObject.getID(), "object " + trackedObject.getID(), globalCoordinates);
                fusionSlam.addLandmark(newLandMark);
                statisticalFolder.incrementNumLandmarks(1);
            } else {
                List<CloudPoint> pointsToUpdate = landMark.getCoordinates();
                pointsToUpdate.addAll(globalCoordinates);
                landMark.setCoordinates(pointsToUpdate);
            }
        }


    }

    public void handlePose(PoseEvent event) {
        Pose pose = event.getPose();
        fusionSlam.addPose(pose);
    }
}
