package bgu.spl.mics.application.objects;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
/**
 * Represents a camera sensor on the robot.
 * Responsible for detecting objects in the environment.
 */
public class Camera {
    private int id;
    private final int frequency;
    private final List<StampedDetectedObjects> detectedObjectList;
    private STATUS status;
    private StampedDetectedObjects lastDetectedObjects;


    //constructor
    public Camera (int id, int frequency, List<StampedDetectedObjects> detectedObjectList ){
        this.id=id;
        this.frequency=frequency;
        this.detectedObjectList= detectedObjectList ;
        this.status = STATUS.UP;
    }

    public int getID(){
        return id;
    }

    public int getFrequency(){
        return frequency;
    }

    public List<StampedDetectedObjects> getDetectedObjectList(){
        return detectedObjectList;
    }

    public void setLastDetectedObjects(StampedDetectedObjects lastDetectedObjects){
        this.lastDetectedObjects = lastDetectedObjects;
    }

    public StampedDetectedObjects getLastDetectedObjects(){
        return lastDetectedObjects;
    }

    public int getTimeOfLastDetection(){
        return detectedObjectList.get(detectedObjectList.size()-1).getTime();
    }

    public void setStatus(STATUS status){
        this.status = status;
    }
}
