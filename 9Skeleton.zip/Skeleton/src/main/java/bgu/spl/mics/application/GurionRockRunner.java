package bgu.spl.mics.application;

import bgu.spl.mics.application.objects.*;
import bgu.spl.mics.application.services.*;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * The main entry point for the GurionRock Pro Max Ultra Over 9000 simulation.
 * <p>
 * This class initializes the system and starts the simulation by setting up
 * services, objects, and configurations.
 * </p>
 */
public class GurionRockRunner {

    /**
     * The main method of the simulation.
     * This method sets up the necessary components, parses configuration files,
     * initializes services, and starts the simulation.
     *
     * @param args Command-line arguments. The first argument is expected to be the path to the configuration file.
     */
    public static void main(String[] args) {
        System.out.println("Hello World!");

        // TODO: Parse configuration file.
        String configPath = args[0];
        JsonObject configData = null;
        try (FileReader reader = new FileReader(configPath)) {
            Gson gson = new Gson();
            configData = gson.fromJson(reader, JsonObject.class);
        }
        catch(IOException e){
            e.printStackTrace();
        }
        // TODO: Initialize system components and services.
        JsonObject camerasConfig = configData.getAsJsonObject("Cameras");
        String cameraDatasPath = camerasConfig.get("camera_datas_path").getAsString();
        JsonArray cameraConfigurations = camerasConfig.getAsJsonArray("CamerasConfigurations");

        JsonObject lidarConfig  = configData.getAsJsonObject("LidarWorkers");
        String lidarDataPath = lidarConfig.get("lidars_data_path").getAsString();
        JsonArray lidarConfigurations = lidarConfig.getAsJsonArray("LidarConfigurations");

        String poseDataPath = configData.get("poseJsonFile").getAsString();
        int tickTime = configData.get("TickTime").getAsInt();
        int duration = configData.get("Duration").getAsInt();

        List<CameraService> cameraServices = initializeCameras(cameraConfigurations, cameraDatasPath);
        List<LiDarService> liDarServices = initializeLidars(lidarConfigurations, lidarDataPath);
        PoseService poseService = initalizePoseService(poseDataPath);
        TimeService timeService = initalizeTimeService(tickTime, duration);
        FusionSlamService fusionSlamService = new FusionSlamService(FusionSlam.getInstance(), cameraServices.size()+liDarServices.size() , duration);
        // TODO: Start the simulation.

    }



    public static List<CameraService> initializeCameras(JsonArray cameraConfigurations, String cameraDatasPath){
        Gson gson = new Gson();
        List<CameraService> services = new ArrayList<CameraService>();
        try (FileReader reader = new FileReader(cameraDatasPath)){
            JsonObject cameraData = gson.fromJson(reader, JsonObject.class);
            for(int i = 0; i<cameraConfigurations.size();i++){
                JsonObject cameraConfig = cameraConfigurations.get(i).getAsJsonObject();
                int cameraId = cameraConfig.get("id").getAsInt();
                int frequency = cameraConfig.get("frequency").getAsInt();
                String cameraKey = cameraConfig.get("camera_key").getAsString();
                JsonArray stampedDetectedObjectsJson = cameraData.getAsJsonArray(cameraKey);
                List<StampedDetectedObjects> stampedDetectedObjectsList = new ArrayList<>();
                for(int j = 0; j<stampedDetectedObjectsJson.size();j++){
                    JsonObject stampedObjectsJson = stampedDetectedObjectsJson.get(j).getAsJsonObject();
                    int time = stampedObjectsJson.get("time").getAsInt();
                    JsonArray detectedObjectsJson = stampedObjectsJson.get("detected_Objects").getAsJsonArray("detectedObjects");
                    List<DetectedObject> detectedObjects = new ArrayList<DetectedObject>();
                    for(int k = 0 ; k<detectedObjectsJson.size();k++){
                        JsonObject detectedObjectJson = detectedObjectsJson.get(k).getAsJsonObject();
                        String objectId = detectedObjectJson.get("id").getAsString();
                        String description = detectedObjectJson.get("description").getAsString();
                        detectedObjects.add(new DetectedObject(objectId, description));
                    }
                    stampedDetectedObjectsList.add(new StampedDetectedObjects(time, detectedObjects))
                }
                Camera camera = new Camera(cameraId, frequency, stampedDetectedObjectsList);
                CameraService cameraService = new CameraService(camera);
                services.add(cameraService);
            }
        }
        catch(IOException e){
            e.printStackTrace();
        }
        return services;
    }
    private static List<LiDarService> initializeLidars(JsonArray lidarConfigurations, String lidarDataPath) {
        LiDarDataBase liDarDataBase = LiDarDataBase.getInstance(lidarDataPath);
        List<LiDarService> liDarServiceList = new ArrayList<LiDarService>();
        for(int i = 0; i<lidarConfigurations.size();i++) {
            JsonObject config = lidarConfigurations.get(i).getAsJsonObject();
            int id = config.get("id").getAsInt();
            int frequency = config.get("frequency").getAsInt();
            LiDarWorkerTracker lidarWorkerTracker = new LiDarWorkerTracker(id, frequency);
            liDarServiceList.add(new LiDarService(lidarWorkerTracker));

        }
        return liDarServiceList;
    }
    public static PoseService initalizePoseService(String poseDataPath){
        Gson gson = new Gson();
        List<Pose> poses = new ArrayList<>();
        try(FileReader reader = new FileReader(poseDataPath)){
            JsonArray poseArrayJson = gson.fromJson(reader, JsonArray.class);
            for(int i = 0; i<poseArrayJson.size();i++){
                JsonObject jsonObject = poseArrayJson.get(i).getAsJsonObject();
                int time = jsonObject.get("time").getAsInt();
                float x = jsonObject.get("x").getAsFloat();
                float y = jsonObject.get("y").getAsFloat();
                float yaw = jsonObject.get("yaw").getAsFloat();
                poses.add(new Pose(x, y, yaw, time));
            }
            GPSIMU gpsimu = new GPSIMU(0, STATUS.UP, poses);
            PoseService poseService = new PoseService(gpsimu);
            return poseService;
        }
        catch (IOException e){
            e.printStackTrace();
        }
    }
    public static TimeService initalizeTimeService(int tickTime, int duration){
        return new TimeService(tickTime, duration);
    }
}


