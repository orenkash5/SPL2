package bgu.spl.mics;

import bgu.spl.mics.application.messages.TrackedObjectsEvent;
import bgu.spl.mics.application.objects.*;
import bgu.spl.mics.application.services.FusionSlamService;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;


import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;

public class fusionSlamServiceTest {
    private FusionSlam fusionSlam;
    private FusionSlamService fusionSlamService;

    @Before
    public void setUp() {
        fusionSlam = FusionSlam.getInstance();
        fusionSlamService = new FusionSlamService(fusionSlam, 2, 20,  new CountDownLatch(1));
    }
    /**
     * Test method for {@link FusionSlamService#transformToGlobal(List, Pose)}.
     * Transforming local coordinates to global coordinates.
     * Precondition:
     * - A robot pose (x=3, y=4, yaw=90 degrees).
     * - A list of local coordinates.
     * Postcondition:
     * - Global coordinates are correctly transformed using the pose.
     */
    @Test
    public void testTransformToGlobal() {
        Pose robotPose = new Pose(3, 4, 90, 1);
        List<CloudPoint> localCoordinates = new ArrayList<>();
        localCoordinates.add(new CloudPoint(1, 0)); // Local coordinates (1, 0)
        localCoordinates.add(new CloudPoint(0, 2)); // Local coordinates (0, 2)

        List<CloudPoint> globalCoordinates = fusionSlamService.transformToGlobal(localCoordinates, robotPose);

        assertEquals(3, globalCoordinates.get(0).getX(), 0.01); // Transformed (1,0) -> (3,5)
        assertEquals(5, globalCoordinates.get(0).getY(), 0.01);

        assertEquals(1, globalCoordinates.get(1).getX(), 0.01); // Transformed (0,2) -> (1,4)
        assertEquals(4, globalCoordinates.get(1).getY(), 0.01);
    }
    /**
     * Test method for {@link FusionSlamService#handleTrackedObjects(TrackedObjectsEvent)}.
     * Adding tracked objects and verifying the landmarks created.
     * Precondition:
     * - A valid pose for the robot is set.
     * - A list of tracked objects is provided with local coordinates.
     * Postcondition:
     * - Landmarks are created with transformed global coordinates.
     */
    @Test
    public void testHandleTrackedObjects() {
        Pose robotPose = new Pose(3, 4, 90, 1);
        fusionSlam.addPose(robotPose);

        List<TrackedObject> trackedObjects = new ArrayList<>();
        List<CloudPoint> localCoordinates = new ArrayList<>();
        localCoordinates.add(new CloudPoint(1, 0));
        trackedObjects.add(new TrackedObject("Wall_1", 1, "Wall", localCoordinates));

        TrackedObjectsEvent event = new TrackedObjectsEvent(trackedObjects, 1);
        fusionSlamService.handleTrackedObjects(event);

        LandMark landmark = fusionSlam.findLandMark("Wall_1");
        assertNotNull(landmark);
        assertEquals(1, landmark.getCoordinates().size());
        assertEquals(3, landmark.getCoordinates().get(0).getX(), 0.01);
        assertEquals(5, landmark.getCoordinates().get(0).getY(), 0.01);
    }

}
