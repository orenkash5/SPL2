package bgu.spl.mics.application.services;

import bgu.spl.mics.MicroService;
import bgu.spl.mics.application.messages.*;
import bgu.spl.mics.application.objects.*;

import java.util.ArrayList;
import java.util.List;

/**
 * LiDarService is responsible for processing data from the LiDAR sensor and
 * sending TrackedObjectsEvents to the FusionSLAM service.
 * 
 * This service interacts with the LiDarTracker object to retrieve and process
 * cloud point data and updates the system's StatisticalFolder upon sending its
 * observations.
 */
public class LiDarService extends MicroService {

    private final LiDarWorkerTracker worker;
    private final LiDarDataBase dataBase;
    private int currentTime;
    private final StatisticalFolder statisticalFolder;
    private final FusionSlam fusionSlam;

    /**
     * Constructor for LiDarService.
     *
     * @param liDarWorkerTracker The LiDAR tracker object that this service will use to process data.
     */
    public LiDarService(LiDarWorkerTracker liDarWorkerTracker, LiDarDataBase dataBase, FusionSlam fusionSlam) {
        super("LiDarService");
        this.worker = liDarWorkerTracker;
        this.fusionSlam = fusionSlam;
        this.dataBase = dataBase;
        this.currentTime = 0;
        statisticalFolder=StatisticalFolder.getInstance();
    }
    public LiDarWorkerTracker getWorker(){return this.worker;}
    /**
     * Initializes the LiDarService.
     * Registers the service to handle DetectObjectsEvents and TickBroadcasts,
     * and sets up the necessary callbacks for processing data.
     */
    @Override
    protected void initialize() {
        // TODO Implement this
        subscribeBroadcast(TickBroadcast.class, Tick -> {
            currentTime=Tick.getCurrentTick();
            if(currentTime > dataBase.getTimeOfLastTrack()) {
                //System.out.println("LidarService: sending sensorTerminated. time: " + event.getDetectedObjects().getTime());
                fusionSlam.sensorTerminated();
                worker.setStatus(STATUS.DOWN);
                terminate();
            }
        });
        subscribeEvent(DetectObjectsEvent.class, this::handleDetectedObjects);
        subscribeBroadcast(TerminatedBroadcast.class, b -> terminate());
        subscribeBroadcast(CrashedBroadcast.class, b -> terminate());

    }

    private void handleDetectedObjects(DetectObjectsEvent event){
//        System.out.println("time of last track: " + dataBase.getTimeOfLastTrack());
//        if(currentTime > dataBase.getTimeOfLastTrack()) {
//            System.out.println("LidarService: sending sensorTerminated. time: " + event.getDetectedObjects().getTime());
//            fusionSlam.sensorTerminated();
//            worker.setStatus(STATUS.DOWN);
//            terminate();
//            return;
//        }
        int detectionTime= event.getDetectedObjects().getTime();
        int processingTime= detectionTime+ worker.getFrequency();;
        if(currentTime >= processingTime){
            List<StampedCloudPoints> StampedCloudPointsList= dataBase.getCloudPoints();
            List<TrackedObject> trackedObjects= new ArrayList<>();
            for(StampedCloudPoints stampedCloudPoints : StampedCloudPointsList){
                if (stampedCloudPoints.getTime() == detectionTime){
                    String ID = stampedCloudPoints.getID();
                    if (ID.equals("ERROR")){
                        System.out.println("LidarService: sending CrashedBroadcast. time: " + detectionTime);
                        sendBroadcast(new CrashedBroadcast("LiDar disconnected", worker.getWorkerName()));
                        worker.setStatus(STATUS.ERROR);
                        terminate();
                        return;
                    }
                    TrackedObject trackedObject= new TrackedObject(ID, stampedCloudPoints.getTime(), event.getDetectedObjects().getDescriptionOfID(ID) , stampedCloudPoints.getCloudPoints());
                    trackedObjects.add(trackedObject);
                }
            }
            statisticalFolder.incrementNumTrackedObjects(trackedObjects.size());
            worker.setLastTrackedObjects(trackedObjects);
            System.out.println("LidarService: sending trackedObjectEvent. time: " + detectionTime);
            sendEvent(new TrackedObjectsEvent(trackedObjects, detectionTime));
            complete(event, Boolean.TRUE);
        }

    }



}
