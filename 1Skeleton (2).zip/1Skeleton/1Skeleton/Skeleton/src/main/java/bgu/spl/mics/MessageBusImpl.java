package bgu.spl.mics;

import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;

/**
 * The {@link MessageBusImpl class is the implementation of the MessageBus interface.
 * Write your implementation here!
 * Only private fields and methods can be added to this class.
 */
public class MessageBusImpl implements MessageBus {
	private static MessageBusImpl instance = null;
	private final Map<Class<?>, Queue<MicroService>> eventSubscribers = new ConcurrentHashMap<>();
	private final Map<Class<?>, Queue<MicroService>> broadcastSubscribers = new ConcurrentHashMap<>();
	private final Map<Event<?>, Future<?>> eventAndFuture = new ConcurrentHashMap<>();
	private final Map<MicroService, Queue<Message>> MSQueues = new ConcurrentHashMap<>();



	@Override
	public <T> void subscribeEvent(Class<? extends Event<T>> type, MicroService m) {
		synchronized (eventSubscribers){
			//System.out.println("MicroService " + m.getName() + " subscribing to event type " + type.getName());
			if( !eventSubscribers.containsKey(type)){
				eventSubscribers.put(type, new LinkedList<>());
			}
			eventSubscribers.computeIfAbsent(type, k -> new LinkedList<>()).add(m);
		}
	}

	@Override
	public void subscribeBroadcast(Class<? extends Broadcast> type, MicroService m) {
		synchronized (broadcastSubscribers){
			//System.out.println("MicroService " + m.getName() + " subscribing to broadcast type " + type.getName());
			if( !broadcastSubscribers.containsKey(type)){
				broadcastSubscribers.put(type, new LinkedList<>());
			}
			broadcastSubscribers.computeIfAbsent(type, k -> new LinkedList<>()).add(m);
		}

	}

	@Override
	public <T> void complete(Event<T> e, T result) {
		System.out.println("Completing event of type " + e.getClass().getName() + " with result: " + result);
		Future<T> future= (Future<T>) eventAndFuture.get(e);
		if (future!=null)
			future.resolve(result);
		else System.out.println("No future found for event " + e.getClass().getName());



	}

	@Override
	public void sendBroadcast(Broadcast b) {
		Class<? extends Broadcast> broadcastType= b.getClass();
		System.out.println("Sending broadcast of type " + broadcastType.getName());
		synchronized (broadcastSubscribers){
			Queue<MicroService> subscribers= broadcastSubscribers.get(broadcastType);
			if (subscribers!=null){
				for(MicroService m: subscribers ){
					Queue<Message> qm= MSQueues.get(m);
					synchronized (qm){
						qm.add(b);
						qm.notifyAll();
						System.out.println("Broadcast added to queue of MicroService " + m.getName());
					}
				}
			}
		}
	}


	@Override
	public <T> Future<T> sendEvent(Event<T> e) {
		Class<? extends Event<T>> eventType= (Class<? extends Event<T>>) e.getClass();
		System.out.println("Sending event of type " + eventType.getName());
		synchronized (eventSubscribers){
			Queue<MicroService> qe= eventSubscribers.get(eventType);
			if(qe==null|| qe.isEmpty()) {
				System.out.println("No subscribers for event type " + eventType.getName());
				return null;
			}
			MicroService ms= qe.poll();
			qe.add(ms);

			Queue<Message> qm= MSQueues.get(ms);
			synchronized (qm){
				qm.add(e);
				qm.notifyAll();
				System.out.println("Event added to queue of MicroService " + ms.getName());
			}

			Future<T> future= new Future<>();
			eventAndFuture.put(e, future);

			return future;
		}
	}



	@Override
	public void register(MicroService m) {
		synchronized (MSQueues){
			System.out.println("Registering MicroService " + m.getName());
			MSQueues.put(m, new LinkedList<>() );
		}

	}

	@Override
	public void unregister(MicroService m) {
		System.out.println("Unregistering MicroService " + m.getName());
		synchronized (MSQueues){
			MSQueues.remove(m);
		}
		synchronized (eventSubscribers){
			for(Queue<MicroService> q : eventSubscribers.values()){
				q.remove(m);
			}
		}
		synchronized (broadcastSubscribers){
			for(Queue<MicroService> q : broadcastSubscribers.values()){
				q.remove(m);
			}

		}

	}

	@Override
	public Message awaitMessage(MicroService m) throws InterruptedException {
		Queue<Message> qm= MSQueues.get(m);
		if(qm==null){
			System.out.println("MicroService " + m.getName() + " was never registered");
		}
		synchronized (qm){
			while(qm.isEmpty()){
				try{
					System.out.println("MicroService " + m.getName() + " is waiting for a message.");
					qm.wait();
				}
				catch (InterruptedException e){
					System.out.println("MicroService " + m.getName() + " was interrupted while waiting for a message.");
					Thread.currentThread().interrupt();
					throw e;
				}
			}
			System.out.println("MicroService " + m.getName() + " received a message.");
			return qm.poll();
		}

	}
	public Map<MicroService, Queue<Message>> getMSQueues(){
		return this.MSQueues;
	}
	public static MessageBusImpl getInstance() {
		if (instance == null) {
			synchronized (MessageBusImpl.class) {
				if (instance == null) {
					System.out.println("Creating a new instance of MessageBusImpl.");
					instance = new MessageBusImpl();
				}
			}
		}
		return instance;
	}



}
