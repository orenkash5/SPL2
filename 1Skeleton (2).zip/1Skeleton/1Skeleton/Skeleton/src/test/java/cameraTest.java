//package bgu.spl.mics.application.objects;
import bgu.spl.mics.application.objects.Camera;
import bgu.spl.mics.application.objects.DetectedObject;
import bgu.spl.mics.application.objects.StampedDetectedObjects;
import bgu.spl.mics.application.objects.TrackedObject;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

public class cameraTest {
    private Camera camera;
    private List<StampedDetectedObjects> StampedDetectedObjects;

    @Before
    public void setUp(){
        StampedDetectedObjects=new ArrayList<>();
        List<DetectedObject> detectedObjects1= new ArrayList<>();
        List<DetectedObject> detectedObjects2= new ArrayList<>();
        detectedObjects1.add(new DetectedObject("1","wall"));
        detectedObjects2.add(new DetectedObject("2","chair"));
        StampedDetectedObjects.add(new StampedDetectedObjects(1,detectedObjects1));
        StampedDetectedObjects.add(new StampedDetectedObjects(2,detectedObjects2));
        Camera camera= new Camera(1,1,StampedDetectedObjects);

    }

    @Test
    public void testGetDetectedObjects(){



    }

    public void testSetLastObjects(){

    }
}
