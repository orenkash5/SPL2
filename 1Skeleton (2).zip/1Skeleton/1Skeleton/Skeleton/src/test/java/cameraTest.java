//package bgu.spl.mics.application.objects;
import org.junit.Test;

public class cameraTest {

    @Test
    public void testPrepareDataBeforeSending(){

    }
}
