import org.junit.Test;

public class messageBusTest {
    @Test
    public void testRegister(){

    }

    public void testUnregister(){

    }




}
