package bgu.spl.mics.application.services;

import bgu.spl.mics.MicroService;
import bgu.spl.mics.application.messages.*;
import bgu.spl.mics.application.objects.*;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;

/**
 * FusionSlamService integrates data from multiple sensors to build and update
 * the robot's global map.
 * <p>
 * This service receives TrackedObjectsEvents from LiDAR workers and PoseEvents from the PoseService,
 * transforming and updating the map with new landmarks.
 */
public class FusionSlamService extends MicroService {
    private final FusionSlam fusionSlam;
    private int currentTime;
    private final StatisticalFolder statisticalFolder;
    int numberOfSensors;
    int duration;
    private final CountDownLatch latch;
    private final ConcurrentHashMap<Integer, List<TrackedObject>> waitingObjects;
    private final String baseOutputDir;

    /**
     * Constructor for FusionSlamService.
     *
     * @param fusionSlam    The FusionSLAM object responsible for managing the global map.
     * @param numberOfSensors Number of sensors in the system.
     * @param duration      Duration of the simulation.
     * @param latch         A latch to synchronize service termination.
     * @param baseOutputDir The directory where output files will be written.
     */
    public FusionSlamService(FusionSlam fusionSlam, int numberOfSensors, int duration, CountDownLatch latch, String baseOutputDir) {
        super("FusionSlamService");
        this.fusionSlam = FusionSlam.getInstance();
        this.currentTime = 0;
        this.statisticalFolder = StatisticalFolder.getInstance();
        this.numberOfSensors = numberOfSensors;
        this.duration = duration;
        this.latch = latch;
        this.waitingObjects = new ConcurrentHashMap<>();
        this.baseOutputDir = baseOutputDir;
    }

    /**
     * Initializes the FusionSlamService.
     * Registers the service to handle TrackedObjectsEvents, PoseEvents, and TickBroadcasts,
     * and sets up callbacks for updating the global map.
     */
    @Override
    protected void initialize() {
        subscribeBroadcast(TickBroadcast.class, this::handleTick);
        subscribeEvent(PoseEvent.class, this::handlePose);
        subscribeEvent(TrackedObjectsEvent.class, this::handleTrackedObjects);
        subscribeBroadcast(TerminatedBroadcast.class, b -> {
            if (currentTime == duration) {
                System.out.println("Writing output file");
                WriteOutputFile(Paths.get(baseOutputDir, "output_file.json").toString());
                latch.countDown();
                terminate();
            } else {
                System.out.println("Condition not met: numberOfTerminatedSensors = " + fusionSlam.getNumberOfTerminatedSensors() +
                        ", numberOfSensors = " + numberOfSensors +
                        ", currentTime = " + currentTime +
                        ", duration = " + duration);
            }
        });
        subscribeBroadcast(CrashedBroadcast.class, b -> {
            String errorDescription = b.getError();
            String faultySensor = b.getFaultySensor();
            System.out.println("Writing error output file");
            WriteErrorFile(Paths.get(baseOutputDir, "error_output.json").toString(), errorDescription, faultySensor);
            latch.countDown();
            terminate();
        });
    }

    private void handleTick(TickBroadcast tick) {
        currentTime = tick.getCurrentTick();
        if (fusionSlam.getNumberOfTerminatedSensors() == numberOfSensors) {
            sendBroadcast(new TerminatedBroadcast());
            System.out.println("Writing output file");
            WriteOutputFile(Paths.get(baseOutputDir, "output_file.json").toString());
            latch.countDown();
            terminate();
        }
    }

    public void handleTrackedObjects(TrackedObjectsEvent event) {
        System.out.println("FusionSlamService: handleTrackedObjects, time:" + currentTime);
        List<TrackedObject> trackedObjects = event.getTrackedObjects();
        Pose currentPose = fusionSlam.getCurrentPose(event.getTime());
        if (currentPose == null) {
            waitingObjects.put(event.getTime(), trackedObjects);
        } else {
            processTrackedObjectEvent(currentPose, trackedObjects);
        }
    }

    private void processTrackedObjectEvent(Pose currentPose, List<TrackedObject> trackedObjects) {
        for (TrackedObject trackedObject : trackedObjects) {
            List<CloudPoint> globalCoordinates = transformToGlobal(trackedObject.getCoordinates(), currentPose);
            LandMark landMark = fusionSlam.findLandMark(trackedObject.getID());
            if (landMark == null) {
                LandMark newLandMark = new LandMark(trackedObject.getID(), trackedObject.getDescription(), globalCoordinates);
                System.out.println("FusionSlam adding LandMark. time: " + currentTime);
                fusionSlam.addLandmark(newLandMark);
                statisticalFolder.incrementNumLandmarks(1);
            } else {
                List<CloudPoint> existingCoordinates = landMark.getCoordinates();
                List<CloudPoint> averagedPoints = averageCoordinates(existingCoordinates, globalCoordinates);
                landMark.setCoordinates(averagedPoints);
            }
        }
    }

    public List<CloudPoint> transformToGlobal(List<CloudPoint> localCoordinates, Pose pose) {
        double xRobot = pose.getX();
        double yRobot = pose.getY();
        double yawRad = Math.toRadians(pose.getYaw());
        double cosTheta = Math.cos(yawRad);
        double sinTheta = Math.sin(yawRad);

        List<CloudPoint> globalCoordinates = new ArrayList<>();
        for (CloudPoint cloudPoint : localCoordinates) {
            double xLocal = cloudPoint.getX();
            double yLocal = cloudPoint.getY();
            double xGlobal = cosTheta * xLocal - sinTheta * yLocal + xRobot;
            double yGlobal = sinTheta * xLocal + cosTheta * yLocal + yRobot;
            globalCoordinates.add(new CloudPoint(xGlobal, yGlobal));
        }
        return globalCoordinates;
    }

    private List<CloudPoint> averageCoordinates(List<CloudPoint> existing, List<CloudPoint> incoming) {
        List<CloudPoint> averaged = new ArrayList<>();
        int minSize = Math.min(existing.size(), incoming.size());
        for (int i = 0; i < minSize; i++) {
            CloudPoint oldPoint = existing.get(i);
            CloudPoint newPoint = incoming.get(i);
            double avgX = (oldPoint.getX() + newPoint.getX()) / 2;
            double avgY = (oldPoint.getY() + newPoint.getY()) / 2;
            averaged.add(new CloudPoint(avgX, avgY));
        }
        if (existing.size() > minSize) {
            averaged.addAll(existing.subList(minSize, existing.size()));
        } else if (incoming.size() > minSize) {
            averaged.addAll(incoming.subList(minSize, incoming.size()));
        }
        return averaged;
    }

    public void handlePose(PoseEvent event) {
        Pose pose = event.getPose();
        System.out.println("FusionSlam adding pose. time: " + pose.getTime());
        fusionSlam.addPose(pose);
        List<TrackedObject> trackedObjects = waitingObjects.remove(pose.getTime());
        if (trackedObjects != null) {
            processTrackedObjectEvent(pose, trackedObjects);
        }
    }

    private void WriteErrorFile(String path, String errorDescription, String faultySensor) {
        try (FileWriter writer = new FileWriter(path)) {
            Gson gson = new Gson();
            JsonObject errorDetails = new JsonObject();
            errorDetails.addProperty("error", errorDescription);
            errorDetails.addProperty("faultySensor", faultySensor);
            gson.toJson(errorDetails, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void WriteOutputFile(String path) {
        try (FileWriter writer = new FileWriter(path)) {
            Gson gson = new Gson();
            JsonObject statistics = new JsonObject();
            statistics.addProperty("systemRuntime", statisticalFolder.getSystemRuntime());
            statistics.addProperty("numDetectedObjects", statisticalFolder.getNumDetectedObjects());
            statistics.addProperty("numTrackedObjects", statisticalFolder.getNumTrackedObjects());
            statistics.addProperty("numLandmarks", statisticalFolder.getNumLandmarks());

            JsonArray landmarks = new JsonArray();
            for (LandMark landMark : fusionSlam.getLandmarks()) {
                JsonObject landmarkJson = new JsonObject();
                landmarkJson.addProperty("id", landMark.getID());
                landmarkJson.addProperty("description", landMark.getDescription());
                JsonArray coordinates = new JsonArray();
                for (CloudPoint point : landMark.getCoordinates()) {
                    JsonObject pointJson = new JsonObject();
                    pointJson.addProperty("x", point.getX());
                    pointJson.addProperty("y", point.getY());
                    coordinates.add(pointJson);
                }
                landmarkJson.add("coordinates", coordinates);
                landmarks.add(landmarkJson);
            }
            JsonObject output = new JsonObject();
            output.add("statistics", statistics);
            output.add("landmarks", landmarks);

            gson.toJson(output, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

