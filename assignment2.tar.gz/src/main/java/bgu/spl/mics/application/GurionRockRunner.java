package bgu.spl.mics.application;

import bgu.spl.mics.application.objects.*;
import bgu.spl.mics.application.services.*;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;

/**
 * The main entry point for the GurionRock Pro Max Ultra Over 9000 simulation.
 * <p>
 * This class initializes the system and starts the simulation by setting up
 * services, objects, and configurations.
 * </p>
 */
public class GurionRockRunner {
    /**
     * The main method of the simulation.
     * This method sets up the necessary components, parses configuration files,
     * initializes services, and starts the simulation.
     *
     * @param args Command-line arguments. The first argument is expected to be the path to the configuration file.
     */
    public static void main(String[] args) {
        if (args.length == 0) {
            System.err.println("Error: Configuration file path not provided.");
            return;
        }

        // Parse the configuration file
        String configPath = args[0];
        File configFile = new File(configPath);
        if (!configFile.exists() || !configFile.isFile()) {
            System.err.println("Error: Invalid configuration file path.");
            return;
        }

        // Determine the base directory for output files (same as configuration file's directory)
        String baseOutputDir = configFile.getParent();

        JsonObject configData;
        try (FileReader reader = new FileReader(configPath)) {
            Gson gson = new Gson();
            configData = gson.fromJson(reader, JsonObject.class);
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }

        // Initialize system components and services
        JsonObject camerasConfig = configData.getAsJsonObject("Cameras");
        String cameraDatasPath = Paths.get(baseOutputDir, camerasConfig.get("camera_datas_path").getAsString()).toString();
        JsonArray cameraConfigurations = camerasConfig.getAsJsonArray("CamerasConfigurations");

        JsonObject lidarConfig = configData.getAsJsonObject("LiDarWorkers");
        String lidarDataPath = Paths.get(baseOutputDir, lidarConfig.get("lidars_data_path").getAsString()).toString();
        JsonArray lidarConfigurations = lidarConfig.getAsJsonArray("LidarConfigurations");

        String poseDataPath = Paths.get(baseOutputDir, configData.get("poseJsonFile").getAsString()).toString();
        int tickTime = configData.get("TickTime").getAsInt();
        int duration = configData.get("Duration").getAsInt();

        ServiceTracker serviceTracker = ServiceTracker.getInstance();
        List<CameraService> cameraServices = initializeCameras(cameraConfigurations, cameraDatasPath);
        List<LiDarService> liDarServices = initializeLidars(lidarConfigurations, lidarDataPath);
        serviceTracker.registerCameraServices(cameraServices);
        serviceTracker.registerLiDarServices(liDarServices);
        PoseService poseService = initalizePoseService(poseDataPath);
        TimeService timeService = initalizeTimeService(tickTime, duration);
        CountDownLatch latch = new CountDownLatch(1);

        // Pass the baseOutputDir to the FusionSlamService
        FusionSlamService fusionSlamService = new FusionSlamService(FusionSlam.getInstance(), cameraServices.size() + liDarServices.size(), duration, latch, baseOutputDir);

        // Start the simulation
        ExecutorService executorService = Executors.newCachedThreadPool();
        executorService.submit(timeService);
        executorService.submit(poseService);
        executorService.submit(fusionSlamService);
        cameraServices.forEach(executorService::submit);
        liDarServices.forEach(executorService::submit);

        executorService.shutdown();
        try {
            latch.await();
            if (!executorService.awaitTermination(duration * tickTime, TimeUnit.SECONDS)) {
                executorService.shutdownNow();
            }
        } catch (InterruptedException e) {
            executorService.shutdownNow();
            Thread.currentThread().interrupt();
        }

        System.out.println("Simulation completed successfully!");
    }

    public static List<CameraService> initializeCameras(JsonArray cameraConfigurations, String cameraDatasPath) {
        Gson gson = new Gson();
        List<CameraService> services = new ArrayList<>();
        try (FileReader reader = new FileReader(cameraDatasPath)) {
            JsonObject cameraData = gson.fromJson(reader, JsonObject.class);
            for (int i = 0; i < cameraConfigurations.size(); i++) {
                JsonObject cameraConfig = cameraConfigurations.get(i).getAsJsonObject();
                int cameraId = cameraConfig.get("id").getAsInt();
                int frequency = cameraConfig.get("frequency").getAsInt();
                String cameraKey = cameraConfig.get("camera_key").getAsString();
                JsonArray stampedDetectedObjectsJson = cameraData.getAsJsonArray(cameraKey);
                List<StampedDetectedObjects> stampedDetectedObjectsList = new ArrayList<>();
                for (int j = 0; j < stampedDetectedObjectsJson.size(); j++) {
                    JsonObject stampedObjectsJson = stampedDetectedObjectsJson.get(j).getAsJsonObject();
                    int time = stampedObjectsJson.get("time").getAsInt();
                    JsonArray detectedObjectsJson = stampedObjectsJson.get("detectedObjects").getAsJsonArray();
                    List<DetectedObject> detectedObjects = new ArrayList<>();
                    for (int k = 0; k < detectedObjectsJson.size(); k++) {
                        JsonObject detectedObjectJson = detectedObjectsJson.get(k).getAsJsonObject();
                        String objectId = detectedObjectJson.get("id").getAsString();
                        String description = detectedObjectJson.get("description").getAsString();
                        detectedObjects.add(new DetectedObject(objectId, description));
                    }
                    stampedDetectedObjectsList.add(new StampedDetectedObjects(time, detectedObjects));
                }
                Camera camera = new Camera(cameraId, frequency, stampedDetectedObjectsList);
                CameraService cameraService = new CameraService(camera, FusionSlam.getInstance());
                services.add(cameraService);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return services;
    }

    private static List<LiDarService> initializeLidars(JsonArray lidarConfigurations, String lidarDataPath) {
        LiDarDataBase liDarDataBase = LiDarDataBase.getInstance(lidarDataPath);
        List<LiDarService> liDarServiceList = new ArrayList<>();
        for (int i = 0; i < lidarConfigurations.size(); i++) {
            JsonObject config = lidarConfigurations.get(i).getAsJsonObject();
            int id = config.get("id").getAsInt();
            int frequency = config.get("frequency").getAsInt();
            LiDarWorkerTracker lidarWorkerTracker = new LiDarWorkerTracker(id, frequency);
            liDarServiceList.add(new LiDarService(lidarWorkerTracker, liDarDataBase, FusionSlam.getInstance()));
        }
        return liDarServiceList;
    }

    public static PoseService initalizePoseService(String poseDataPath) {
        Gson gson = new Gson();
        List<Pose> poses = new ArrayList<>();
        try (FileReader reader = new FileReader(poseDataPath)) {
            JsonArray poseArrayJson = gson.fromJson(reader, JsonArray.class);
            for (int i = 0; i < poseArrayJson.size(); i++) {
                JsonObject jsonObject = poseArrayJson.get(i).getAsJsonObject();
                int time = jsonObject.get("time").getAsInt();
                float x = jsonObject.get("x").getAsFloat();
                float y = jsonObject.get("y").getAsFloat();
                float yaw = jsonObject.get("yaw").getAsFloat();
                poses.add(new Pose(x, y, yaw, time));
            }
            GPSIMU gpsimu = new GPSIMU(0, STATUS.UP, poses);
            return new PoseService(gpsimu);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static TimeService initalizeTimeService(int tickTime, int duration) {
        return new TimeService(tickTime, duration);
    }
}

