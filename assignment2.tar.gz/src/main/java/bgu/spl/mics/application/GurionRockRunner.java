package bgu.spl.mics.application;

import bgu.spl.mics.MicroService;
import bgu.spl.mics.application.objects.*;
import bgu.spl.mics.application.services.*;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;

/**
 * The main entry point for the GurionRock Pro Max Ultra Over 9000 simulation.
 * <p>
 * This class initializes the system and starts the simulation by setting up
 * services, objects, and configurations.
 * </p>
 */
public class GurionRockRunner {

    //private static final int EXTRA_TIME_BUFFER = 10;


    /**
     * The main method of the simulation.
     * This method sets up the necessary components, parses configuration files,
     * initializes services, and starts the simulation.
     *
     * @param args Command-line arguments. The first argument is expected to be the path to the configuration file.
     */
    public static void main(String[] args)
    {
        //System.out.println("Hello World!");
        if (args.length == 0) {
            System.err.println("Error: Configuration file path not provided.");
            return;
        }
        // TODO: Parse configuration file.
        String configPath = args[0];
        JsonObject configData = null;
        try (FileReader reader = new FileReader(configPath)) {
            Gson gson = new Gson();
            configData = gson.fromJson(reader, JsonObject.class);
        } catch (IOException e) {
            e.printStackTrace();
        }
        // TODO: Initialize system components and services.
        String baseInputDir = "./src/input/";

        JsonObject camerasConfig = configData.getAsJsonObject("Cameras");
        String cameraDatasPath = baseInputDir + camerasConfig.get("camera_datas_path").getAsString().replace("./", "");
        JsonArray cameraConfigurations = camerasConfig.getAsJsonArray("CamerasConfigurations");

        JsonObject lidarConfig = configData.getAsJsonObject("LiDarWorkers");
        String lidarDataPath = baseInputDir + lidarConfig.get("lidars_data_path").getAsString().replace("./", "");
        JsonArray lidarConfigurations = lidarConfig.getAsJsonArray("LidarConfigurations");

        String poseDataPath = baseInputDir + configData.get("poseJsonFile").getAsString().replace("./", "");
        int tickTime = configData.get("TickTime").getAsInt();
        int duration = configData.get("Duration").getAsInt();


        ServiceTracker serviceTracker = ServiceTracker.getInstance();
        List<CameraService> cameraServices = initializeCameras(cameraConfigurations, cameraDatasPath);
        List<LiDarService> liDarServices = initializeLidars(lidarConfigurations, lidarDataPath);
        serviceTracker.registerCameraServices(cameraServices);
        serviceTracker.registerLiDarServices(liDarServices);
        PoseService poseService = initalizePoseService(poseDataPath);
        TimeService timeService = initalizeTimeService(tickTime, duration);
        CountDownLatch latch= new CountDownLatch(1);
        FusionSlamService fusionSlamService = new FusionSlamService(FusionSlam.getInstance(), cameraServices.size() + liDarServices.size(), duration, latch);
        // TODO: Start the simulation.
        ExecutorService executorService = Executors.newCachedThreadPool();

        executorService.submit(timeService);
        executorService.submit(poseService);
        executorService.submit(fusionSlamService);
        cameraServices.forEach(executorService::submit);
        liDarServices.forEach(executorService::submit);

        executorService.shutdown();
        try {
            latch.await();
            if (!executorService.awaitTermination(duration * tickTime, TimeUnit.SECONDS)) {
                executorService.shutdownNow();
            }
        } catch (InterruptedException e) {
            executorService.shutdownNow();
            Thread.currentThread().interrupt();
        }

        System.out.println("Simulation completed successfully!");
    }

//        List<Thread> serviceThreads = new ArrayList<>();
//        serviceThreads.add(startServiceThread(timeService));
//        serviceThreads.add(startServiceThread(poseService));
//        serviceThreads.add(startServiceThread(fusionSlamService));
//
//        for (CameraService cameraService : cameraServices) {
//            serviceThreads.add(startServiceThread(cameraService));
//        }
//
//        for (LiDarService liDarService : liDarServices) {
//            serviceThreads.add(startServiceThread(liDarService));
//        }

    //System.out.println("joining");
    // Wait for all services to complete
        /*
        for (Thread thread : serviceThreads) {
            try {
                thread.join();
            } catch (InterruptedException e) {
                System.err.println("Simulation interrupted.");
                e.printStackTrace();
            }
        }
        */

    //  System.out.println("Simulation completed successfully!");
//    }
//    private static Thread startServiceThread(MicroService service) {
//        Thread thread = new Thread(service);
//        System.out.println("Starting service: " + service.getName());
//        thread.start();
//        return thread;
//    }


    public static List<CameraService> initializeCameras(JsonArray cameraConfigurations, String cameraDatasPath){
        Gson gson = new Gson();
        List<CameraService> services = new ArrayList<>();
        try (FileReader reader = new FileReader(cameraDatasPath)){
            JsonObject cameraData = gson.fromJson(reader, JsonObject.class);
            for(int i = 0; i<cameraConfigurations.size();i++){
                JsonObject cameraConfig = cameraConfigurations.get(i).getAsJsonObject();
                int cameraId = cameraConfig.get("id").getAsInt();
                int frequency = cameraConfig.get("frequency").getAsInt();
                String cameraKey = cameraConfig.get("camera_key").getAsString();
                JsonArray stampedDetectedObjectsJson = cameraData.getAsJsonArray(cameraKey);
                List<StampedDetectedObjects> stampedDetectedObjectsList = new ArrayList<>();
                for(int j = 0; j<stampedDetectedObjectsJson.size();j++){
                    JsonObject stampedObjectsJson = stampedDetectedObjectsJson.get(j).getAsJsonObject();
                    int time = stampedObjectsJson.get("time").getAsInt();
                    JsonArray detectedObjectsJson = stampedObjectsJson.get("detectedObjects").getAsJsonArray();
                    List<DetectedObject> detectedObjects = new ArrayList<DetectedObject>();
                    for(int k = 0 ; k<detectedObjectsJson.size();k++){
                        JsonObject detectedObjectJson = detectedObjectsJson.get(k).getAsJsonObject();
                        String objectId = detectedObjectJson.get("id").getAsString();
                        String description = detectedObjectJson.get("description").getAsString();
                        detectedObjects.add(new DetectedObject(objectId, description));
                    }
                    stampedDetectedObjectsList.add(new StampedDetectedObjects(time, detectedObjects));
                }
                Camera camera = new Camera(cameraId, frequency, stampedDetectedObjectsList);
                CameraService cameraService = new CameraService(camera, FusionSlam.getInstance());
                services.add(cameraService);
            }
        }
        catch(IOException e){
            e.printStackTrace();
        }
        return services;
    }
    private static List<LiDarService> initializeLidars(JsonArray lidarConfigurations, String lidarDataPath) {
        LiDarDataBase liDarDataBase = LiDarDataBase.getInstance(lidarDataPath);
        List<LiDarService> liDarServiceList = new ArrayList<LiDarService>();
        for(int i = 0; i<lidarConfigurations.size();i++) {
            JsonObject config = lidarConfigurations.get(i).getAsJsonObject();
            int id = config.get("id").getAsInt();
            int frequency = config.get("frequency").getAsInt();
            LiDarWorkerTracker lidarWorkerTracker = new LiDarWorkerTracker(id, frequency);
            liDarServiceList.add(new LiDarService(lidarWorkerTracker, liDarDataBase, FusionSlam.getInstance()));

        }
        return liDarServiceList;
    }
    public static PoseService initalizePoseService(String poseDataPath){
        Gson gson = new Gson();
        List<Pose> poses = new ArrayList<>();
        try(FileReader reader = new FileReader(poseDataPath)){
            JsonArray poseArrayJson = gson.fromJson(reader, JsonArray.class);
            for(int i = 0; i<poseArrayJson.size();i++){
                JsonObject jsonObject = poseArrayJson.get(i).getAsJsonObject();
                int time = jsonObject.get("time").getAsInt();
                float x = jsonObject.get("x").getAsFloat();
                float y = jsonObject.get("y").getAsFloat();
                float yaw = jsonObject.get("yaw").getAsFloat();
                poses.add(new Pose(x, y, yaw, time));
            }
            GPSIMU gpsimu = new GPSIMU(0, STATUS.UP, poses);
            PoseService poseService = new PoseService(gpsimu);
            return poseService;
        }
        catch (IOException e){
            e.printStackTrace();
        }
        return null;
    }
    public static TimeService initalizeTimeService(int tickTime, int duration){
        return new TimeService(tickTime, duration);
    }
}


