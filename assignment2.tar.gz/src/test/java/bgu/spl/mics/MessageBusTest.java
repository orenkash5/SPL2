package bgu.spl.mics;

import bgu.spl.mics.application.messages.PoseEvent;
import bgu.spl.mics.application.objects.*;
import bgu.spl.mics.application.services.CameraService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class MessageBusTest {
    private MessageBusImpl messageBus;
    private MicroService cameraService;

    @BeforeEach
    public void setUp() {
        messageBus = MessageBusImpl.getInstance();
        cameraService = new CameraService(new Camera(1, 1, new ArrayList<StampedDetectedObjects>()), FusionSlam.getInstance());
    }

    @Test
    public void testRegister() {
        messageBus.register(cameraService);
        assertTrue(messageBus.getMSQueues().containsKey(cameraService));
    }

    @Test
    public void testUnregister() {
        messageBus.register(cameraService);
        messageBus.unregister(cameraService);
        assertFalse(messageBus.getMSQueues().containsKey(cameraService));
    }

    @Test
    public void testSubscribeEvent() throws InterruptedException {
        messageBus.register(cameraService);
        messageBus.subscribeEvent(PoseEvent.class, cameraService);

        PoseEvent poseEvent = new PoseEvent(new Pose(2, 4, 45, 1));
        messageBus.sendEvent(poseEvent);

        Message receivedMessage = messageBus.awaitMessage(cameraService);
        assertEquals(poseEvent, receivedMessage);
    }
}
