package bgu.spl.mics.application.objects;

import java.util.concurrent.atomic.AtomicInteger;

/**
 * Holds statistical information about the system's operation.
 * This class aggregates metrics such as the runtime of the system,
 * the number of objects detected and tracked, and the number of landmarks identified.
 */
public class StatisticalFolder {

    private final AtomicInteger systemRuntime;
    private final AtomicInteger numDetectedObjects;
    private final AtomicInteger numTrackedObjects;
    private final AtomicInteger numLandmarks;

    private static class StatisticalFolderHolder{
        private final static StatisticalFolder instance = new StatisticalFolder();
    }

    private StatisticalFolder(){
        systemRuntime = new AtomicInteger(0);
        numDetectedObjects = new AtomicInteger(0);
        numTrackedObjects = new AtomicInteger(0);
        numLandmarks = new AtomicInteger(0);
    }

    public static StatisticalFolder getInstance(){
        return StatisticalFolderHolder.instance;
    }

    public int getSystemRuntime() {
        return systemRuntime.get();
    }
    public int getNumDetectedObjects() {
        return numDetectedObjects.get();
    }

    public int getNumTrackedObjects() {
        return numTrackedObjects.get();
    }

    public int getNumLandmarks() {
        return numLandmarks.get();
    }

    //public void setSystemRuntime(int systemRuntime) {
//        this.systemRuntime = systemRuntime;
//    }

//    public void setNumDetectedObjects(int numDetectedObjects) {
//        this.numDetectedObjects = numDetectedObjects;
//    }

//    public void setNumTrackedObjects(int numTrackedObjects) {
//        this.numTrackedObjects = numTrackedObjects;
//    }

//    public void setNumLandmarks(int numLandmarks) {
//        this.numLandmarks = numLandmarks;
//    }
    public void incrementSystemRuntime(int time) {
        systemRuntime.addAndGet(time);
    }

    public void incrementNumDetectedObjects(int num) {
        numDetectedObjects.addAndGet(num);

    }

    public void incrementNumTrackedObjects(int num) {
        numTrackedObjects.addAndGet(num);
    }

    public void incrementNumLandmarks(int num) {
        numLandmarks.addAndGet(num);
    }
}
