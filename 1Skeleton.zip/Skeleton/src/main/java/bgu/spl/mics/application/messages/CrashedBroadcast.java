package bgu.spl.mics.application.messages;

import bgu.spl.mics.Broadcast;

public class CrashedBroadcast implements Broadcast {
    private String error;
    private String faultySensor;

    public CrashedBroadcast(String error, String faultySensor) {
        this.error = error;
        this.faultySensor = faultySensor;
    }

    public String getError() {
        return error;
    }

    public String getFaultySensor() {
        return faultySensor;
    }
}