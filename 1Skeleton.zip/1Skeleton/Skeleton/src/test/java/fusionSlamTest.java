import org.junit.Test;

public class fusionSlamTest {
    @Test
    public void trackedObjectsToLandmarks() {
    }
}
