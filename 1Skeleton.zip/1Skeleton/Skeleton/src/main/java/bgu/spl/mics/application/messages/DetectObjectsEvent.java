package bgu.spl.mics.application.messages;
import bgu.spl.mics.Event;
import bgu.spl.mics.application.objects.DetectedObject;
import bgu.spl.mics.application.objects.StampedDetectedObjects;
import bgu.spl.mics.application.objects.TrackedObject;

import java.util.List;

public class DetectObjectsEvent implements Event<Boolean>{
    private StampedDetectedObjects detectedObjects;


    public DetectObjectsEvent(StampedDetectedObjects detectedObjects) {
        this.detectedObjects = detectedObjects;

    }
    public StampedDetectedObjects getDetectedObjects() {
        return detectedObjects;
    }

}
