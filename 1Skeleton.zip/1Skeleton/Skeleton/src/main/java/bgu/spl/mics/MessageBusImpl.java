package bgu.spl.mics;

import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;

/**
 * The {@link MessageBusImpl class is the implementation of the MessageBus interface.
 * Write your implementation here!
 * Only private fields and methods can be added to this class.
 */
public class MessageBusImpl implements MessageBus {
	private static MessageBusImpl instance = null;
	private final Map<Class<?>, Queue<MicroService>> eventSubscribers = new ConcurrentHashMap<>();
	private final Map<Class<?>, Queue<MicroService>> broadcastSubscribers = new ConcurrentHashMap<>();
	private final Map<Event<?>, Future<?>> eventAndFuture = new ConcurrentHashMap<>();
	private final Map<MicroService, Queue<Message>> MSQueues = new ConcurrentHashMap<>();



	@Override
	public <T> void subscribeEvent(Class<? extends Event<T>> type, MicroService m) {
		synchronized (eventSubscribers){
			if( !eventSubscribers.containsKey(type)){
				eventSubscribers.put(type, new LinkedList<>());
			}
			eventSubscribers.computeIfAbsent(type, k -> new LinkedList<>()).add(m);
		}
	}

	@Override
	public void subscribeBroadcast(Class<? extends Broadcast> type, MicroService m) {
		synchronized (broadcastSubscribers){
			if( !broadcastSubscribers.containsKey(type)){
				broadcastSubscribers.put(type, new LinkedList<>());
			}
			broadcastSubscribers.computeIfAbsent(type, k -> new LinkedList<>()).add(m);
		}

	}

	@Override
	public <T> void complete(Event<T> e, T result) {
		Future<T> future= (Future<T>) eventAndFuture.get(e);
		future.resolve(result);



	}

	@Override
	public void sendBroadcast(Broadcast b) {
		Class<? extends Broadcast> broadcastType= b.getClass();
		synchronized (broadcastSubscribers){
			Queue<MicroService> subscribers= broadcastSubscribers.get(broadcastType);
			if (subscribers!=null){
				for(MicroService m: subscribers ){
					Queue<Message> qm= MSQueues.get(m);
					synchronized (qm){
						qm.add(b);
						qm.notifyAll();
					}
				}
			}
		}
	}


	@Override
	public <T> Future<T> sendEvent(Event<T> e) {
		Class<? extends Event<T>> eventType= (Class<? extends Event<T>>) e.getClass();
		synchronized (eventSubscribers){
			Queue<MicroService> qe= eventSubscribers.get(eventType);
			if(qe==null|| qe.isEmpty()) {
				return null;
			}
			MicroService ms= qe.poll();
			qe.add(ms);

			Queue<Message> qm= MSQueues.get(ms);
			synchronized (qm){
				qm.add(e);
				qm.notifyAll();
			}

			Future<T> future= new Future<>();
			eventAndFuture.put(e, future);

			return future;
		}
	}



	@Override
	public void register(MicroService m) {
		synchronized (MSQueues){
			//maybe need to check if m doesn't have already a queue and replace with putIfAbsent
			MSQueues.put(m, new LinkedList<>() );
		}

	}

	@Override
	public void unregister(MicroService m) {
		synchronized (MSQueues){
			MSQueues.remove(m);
		}
		synchronized (eventSubscribers){
			for(Queue<MicroService> q : eventSubscribers.values()){
				q.remove(m);
			}
		}
		synchronized (broadcastSubscribers){
			for(Queue<MicroService> q : broadcastSubscribers.values()){
				q.remove(m);
			}

		}

	}

	@Override
	public Message awaitMessage(MicroService m) throws InterruptedException {
		Queue<Message> qm= MSQueues.get(m);
		synchronized (qm){
			while(qm.isEmpty()){
				try{
					qm.wait();
				}
				catch (InterruptedException e){
					Thread.currentThread().interrupt();
					throw e;
				}
			}
			return qm.poll();
		}

	}

	public static MessageBusImpl getInstance() {
		if (instance == null) {
			synchronized (MessageBusImpl.class) {
				if (instance == null) {
					instance = new MessageBusImpl();
				}
			}
		}
		return instance;
	}



}
