package bgu.spl.mics.application.objects;

import java.util.List;

/**
 * Manages the fusion of sensor data for simultaneous localization and mapping (SLAM).
 * Combines data from multiple sensors (e.g., LiDAR, camera) to build and update a global map.
 * Implements the Singleton pattern to ensure a single instance of FusionSlam exists.
 */
public class FusionSlam {
    private List<LandMark> landmarks;
    private List<Pose> Poses;
    private List<CloudPoint> coordinates;
    // Singleton instance holder
    private static class FusionSlamHolder {
        // TODO: Implement singleton instance logic.
        private static final FusionSlam instance = new FusionSlam();

    }
    public static FusionSlam getInstance() {
        return FusionSlamHolder.instance;
    }
    public List<LandMark> getLandmarks(){
        return landmarks;
    }
    public List<Pose> getPoses(){
        return Poses;
    }
    public List<CloudPoint> getCoordinates(){
        return coordinates;
    }
    public void addLandmark(LandMark landmark) {
        if(landmark != null)
            landmarks.add(landmark);
    }
    public void addPose(Pose pose) {
        if(pose != null)
            Poses.add(pose);
    }
    public void addCloudPoints(List<CloudPoint> cloudPoints) {
        if(cloudPoints != null)
            coordinates.addAll(cloudPoints);
    }
    public LandMark findLandMark(String id) {
        for (LandMark landmark : landmarks) {
            if (landmark.getID().equals(id))
                return landmark;
        }
        return null;
    }
}
