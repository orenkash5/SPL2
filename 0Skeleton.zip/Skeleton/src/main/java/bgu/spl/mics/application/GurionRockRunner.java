package bgu.spl.mics.application;

import bgu.spl.mics.MessageBusImpl;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import java.io.FileReader;
import java.io.IOException;

/**
 * The main entry point for the GurionRock Pro Max Ultra Over 9000 simulation.
 * <p>
 * This class initializes the system and starts the simulation by setting up
 * services, objects, and configurations.
 * </p>
 */
public class GurionRockRunner {

    /**
     * The main method of the simulation.
     * This method sets up the necessary components, parses configuration files,
     * initializes services, and starts the simulation.
     *
     * @param args Command-line arguments. The first argument is expected to be the path to the configuration file.
     */
    public static void main(String[] args) {
        System.out.println("Hello World!");

        // TODO: Parse configuration file.
        String configPath = args[0];
        JsonObject configData = null;
        try (FileReader reader = new FileReader(configPath)) {
            Gson gson = new Gson();
            configData = gson.fromJson(reader, JsonObject.class);
        }
        catch(IOException e){
            e.printStackTrace();
        }
        // TODO: Initialize system components and services.

        // TODO: Start the simulation.
    }
}
