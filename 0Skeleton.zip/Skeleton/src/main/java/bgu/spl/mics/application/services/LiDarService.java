package bgu.spl.mics.application.services;

import bgu.spl.mics.MicroService;
import bgu.spl.mics.application.messages.*;
import bgu.spl.mics.application.objects.*;

import java.util.ArrayList;
import java.util.List;

/**
 * LiDarService is responsible for processing data from the LiDAR sensor and
 * sending TrackedObjectsEvents to the FusionSLAM service.
 * 
 * This service interacts with the LiDarTracker object to retrieve and process
 * cloud point data and updates the system's StatisticalFolder upon sending its
 * observations.
 */
public class LiDarService extends MicroService {

    private final LiDarWorkerTracker worker;
    private LiDarDataBase dataBase;
    private int currentTime;
    private final StatisticalFolder statisticalFolder;

    /**
     * Constructor for LiDarService.
     *
     * @param liDarWorkerTracker The LiDAR tracker object that this service will use to process data.
     */
    public LiDarService(LiDarWorkerTracker liDarWorkerTracker) {
        super("LiDarService");
        this.worker = liDarWorkerTracker;
        //this.dataBase = LiDarDataBase.getInstance(worker.getFilePath());
        this.currentTime = 0;
        statisticalFolder=StatisticalFolder.getInstance();
    }

    /**
     * Initializes the LiDarService.
     * Registers the service to handle DetectObjectsEvents and TickBroadcasts,
     * and sets up the necessary callbacks for processing data.
     */
    @Override
    protected void initialize() {
        // TODO Implement this
        subscribeBroadcast(TickBroadcast.class, Tick -> {
            currentTime=Tick.getCurrentTick();
        });
        subscribeEvent(DetectObjectsEvent.class, this::handleDetectedObjects);
        subscribeBroadcast(TerminatedBroadcast.class, b -> terminate());
        subscribeBroadcast(CrashedBroadcast.class, b -> terminate());

    }

    private void handleDetectedObjects(DetectObjectsEvent event){
        int processingTime= currentTime+ worker.getFrequency();;
        if(currentTime >= processingTime){
            List<StampedCloudPoints> StampedCloudPoints= dataBase.getCloudPoints();
            List<TrackedObject> trackedObjects= new ArrayList<>();
            for(StampedCloudPoints stampedCloudPoints : StampedCloudPoints){
                if (stampedCloudPoints.getTime() == event.getTime()){
                    String ID= stampedCloudPoints.getID();
                    if (ID.equals("ERROR")){
                        sendBroadcast(new CrashedBroadcast());
                        worker.setStatus(STATUS.ERROR);
                        terminate();
                        return;
                    }
                    TrackedObject trackedObject= new TrackedObject(ID, stampedCloudPoints.getTime(), event.getDetectedObjects().getDescriptionOfID(ID) , stampedCloudPoints.getCloudPoints());
                    trackedObjects.add(trackedObject);
                }
            }
            statisticalFolder.incrementNumTrackedObjects(trackedObjects.size());
            worker.setLastTrackedObjects(trackedObjects);
            sendEvent(new TrackedObjectsEvent(trackedObjects));
            complete(event, Boolean.TRUE);

        }

    }



}
