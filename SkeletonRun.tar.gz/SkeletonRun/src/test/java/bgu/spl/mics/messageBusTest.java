package bgu.spl.mics;

import bgu.spl.mics.application.messages.PoseEvent;
import bgu.spl.mics.application.objects.*;
import bgu.spl.mics.application.services.CameraService;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertEquals;

import java.util.ArrayList;

public class messageBusTest {
    private MessageBusImpl messageBus;
    private MicroService cameraService;
    private MicroService lidarService;

    @Before
    public void setUp() {
        messageBus = MessageBusImpl.getInstance();
        cameraService = new CameraService(new Camera(1, 1, new ArrayList<StampedDetectedObjects>()), FusionSlam.getInstance());
    }
    /**
     * Test method for {@link MessageBusImpl#register(MicroService)}.
     * Registering a microservice.
     * Precondition:
     * - The cameraService is not registered in the MessageBus.
     * Postcondition:
     * - The cameraService is successfully added to the MessageBus' queue map.
     */
    @Test
    public void testRegister(){
        messageBus.register(cameraService);
        assertTrue(messageBus.getMSQueues().containsKey(cameraService));
    }
    /**
     * Test method for {@link MessageBusImpl#unregister(MicroService)}.
     * Unregistering a microservice.
     * Precondition:
     * - The cameraService is registered in the MessageBus.
     * Postcondition:
     * - The cameraService is removed from the MessageBus' queue map.
     */
    @Test
    public void testUnregister(){
        messageBus.register(cameraService);
        messageBus.unregister(cameraService);
        assertFalse(messageBus.getMSQueues().containsKey(cameraService));
    }
    /**
     * Test method for {@link MessageBusImpl#subscribeEvent(Class, MicroService)}.
     * Subscribing to an event and receiving it.
     * Precondition:
     * - The cameraService is registered in the MessageBus.
     * - The cameraService is subscribed to PoseEvent.
     * - A PoseEvent is sent to the MessageBus.
     * Postcondition:
     * - The cameraService successfully receives the PoseEvent.
     */
    @Test
    public void testSubscribeEvent() throws InterruptedException {
        messageBus.register(cameraService);
        messageBus.subscribeEvent(PoseEvent.class, cameraService);

        PoseEvent poseEvent = new PoseEvent(new Pose(2, 4, 45, 1));
        messageBus.sendEvent(poseEvent);

        Message receivedMessage = messageBus.awaitMessage(cameraService);
        assertEquals(poseEvent, receivedMessage);
    }
}
