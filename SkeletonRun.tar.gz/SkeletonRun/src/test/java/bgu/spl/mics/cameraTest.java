package bgu.spl.mics;//package bgu.spl.mics.application.objects;
import bgu.spl.mics.application.objects.Camera;
import bgu.spl.mics.application.objects.DetectedObject;
import bgu.spl.mics.application.objects.StampedDetectedObjects;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

public class cameraTest {
    private Camera camera;
    private List<StampedDetectedObjects> StampedDetectedObjects;

    @Before
    public void setUp(){
        StampedDetectedObjects=new ArrayList<>();
        List<DetectedObject> detectedObjects1= new ArrayList<>();
        List<DetectedObject> detectedObjects2= new ArrayList<>();
        detectedObjects1.add(new DetectedObject("1","wall"));
        detectedObjects2.add(new DetectedObject("2","chair"));
        StampedDetectedObjects.add(new StampedDetectedObjects(1,detectedObjects1));
        StampedDetectedObjects.add(new StampedDetectedObjects(2,detectedObjects2));
        this.camera= new Camera(1,1,StampedDetectedObjects);

    }
    /**
     * Test method for {@link Camera#getDetectedObjectList()}.
     */

    @Test
    public void testGetDetectedObjects(){
        List<StampedDetectedObjects> expected= StampedDetectedObjects;
        List<StampedDetectedObjects> actual= camera.getDetectedObjectList();
        assertEquals(expected,actual);
    }

    @Test
    public void testGetDetectedObjectsEmpty(){
        Camera emptycamera= new Camera(2,5,new ArrayList<>());
        assertEquals(0,emptycamera.getDetectedObjectList().size());
    }
    /**
     * Test method for {@link Camera#setLastDetectedObjects(StampedDetectedObjects)}.
     */

    @Test
    public void testSetLastObjects(){
        assertNull(camera.getLastDetectedObjects());

        StampedDetectedObjects nLast= StampedDetectedObjects.get(1);
        camera.setLastDetectedObjects(nLast);
        assertEquals(camera.getLastDetectedObjects(),nLast);

    }
}
