package bgu.spl.mics.application.objects;
import java.util.LinkedList;
import java.util.List;
/**
 * Represents a camera sensor on the robot.
 * Responsible for detecting objects in the environment.
 */
public class Camera {
    private int id;
    private final int frequency;
    private List<StampedDetectedObjects> detectedObjectList;
    private STATUS status;

    //constructor
    public Camera (int id, int frequency, List<StampedDetectedObjects> detectedObjectList ){
        this.id=id;
        this.frequency=frequency;
        this.detectedObjectList= detectedObjectList ;
        this.status = STATUS.UP;
    }

    public int getFrequency(){
        return frequency;
    }

    public StampedDetectedObjects getDetectionsForTick(int tick){
        for(StampedDetectedObjects objects: detectedObjectList ){
            if(objects.getTime()==tick){
                return objects;
            }
        }
        return null;

    }

    public void setStatus(STATUS status){
        this.status = status;
    }
}
