

package bgu.spl.mics;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public abstract class MicroService implements Runnable {

    private String name;
    private boolean terminated;
    private MessageBusImpl messageBus;
    private Map<Class<?>, Callback<?>> messageToCallback; // Message type to callback

    public MicroService(String name) {
        this.name = name;
        this.terminated = false;
        this.messageBus = MessageBusImpl.getInstance(); // Get the singleton instance
        this.messageToCallback = new HashMap<>();
    }


    /**
     * Subscribes to events of a specific type with a specific callback.
     * @param <T> The type of the result.
     * @param type The event class type.
     * @param callback The callback to be called for the event
     */
    protected <T> void subscribeEvent(Class<? extends Event<T>> type, Callback<T> callback) {
        messageBus.subscribeEvent(type, this);
        messageToCallback.put(type, callback);
    }

    /**
     * Subscribes to broadcast messages of a specific type with a specific callback.
     * @param type The event class type.
     * @param callback The callback to be called for the broadcast message.
     */
    protected void subscribeBroadcast(Class<? extends Broadcast> type, Callback<Broadcast> callback) {
        messageBus.subscribeBroadcast(type, this);
        messageToCallback.put(type, callback);
    }

    /**
     * Sends a broadcast message to all subscribed services.
     * @param b The broadcast message to send
     */
    protected void sendBroadcast(Broadcast b) {
        messageBus.sendBroadcast(b);
    }

    /**
     * Sends an event to the MessageBus and saves the related future.
     * @param <T> The type of the result.
     * @param e The event to be sent.
     * @return A future object that will be resolved with the result of the event.
     */
    protected <T> Future<T> sendEvent(Event<T> e) {
        Future<T> future = messageBus.sendEvent(e);
        return future;
    }

    /**
     * Completes an event and resolves the future with the given result.
     * @param <T> The type of the result.
     * @param e The completed event.
     * @param result The result of the completed event.
     */
    protected <T> void complete(Event<T> e, T result) {
        messageBus.complete(e, result);
    }

    /**
     * Used by sub classes of `Microservice` to register for events and broadcasts.
     */

    /**
     * Initializes the microservice, must be implemented by sub classes.
     */
    protected abstract void initialize();

    /**
     * Marks the microservice as terminated.
     */
    protected void terminate() {
        this.terminated = true;
    }

    /**
     * Retrieves the name of the service
     */
    public String getName() {
        return name;
    }

    /**
     * Checks if the service is terminated.
     * @return True if terminated, else false.
     */
    public boolean isTerminated() {
        return terminated;
    }

    /**
     * The thread's run method.
     */
    @Override
    public final void run() {
        messageBus.register(this); // Register with message bus
        initialize(); // Call the initialize method defined in sub classes

        while (!terminated) { // While the microservice is running
            Message message = messageBus.awaitMessage(this); // Retrieve message, this is a blocking call.
            if (message != null) { //If a message was retrieved
                // get callback function for the message.
                Callback<?> callback = messageToCallback.get(message.getClass());
                if (callback != null) {
                    try {
                        //execute the callback function
                        callback.call(message);
                    } catch (Exception e) {
                        System.out.println(getName() + " Crashed due to " + e.getMessage());
                        terminated = true;
                    }
                }
            }
        }
        messageBus.unregister(this); // Unregister when terminated
    }

}
