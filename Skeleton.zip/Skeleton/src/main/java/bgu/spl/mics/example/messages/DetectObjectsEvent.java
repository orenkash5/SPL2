package bgu.spl.mics.example.messages;
import bgu.spl.mics.Event;
import bgu.spl.mics.application.objects.DetectedObject;

public class DetectObjectsEvent implements Event<DetectedObject>{
}
