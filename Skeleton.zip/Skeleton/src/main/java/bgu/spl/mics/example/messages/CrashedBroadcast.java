package bgu.spl.mics.example.messages;

import bgu.spl.mics.Broadcast;

public class CrashedBroadcast implements Broadcast {}

