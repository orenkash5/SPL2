package bgu.spl.mics.application.objects;


import java.util.List;

/**
 * Represents the robot's GPS and IMU system.
 * Provides information about the robot's position and movement.
 */
public class GPSIMU {
    // TODO: Define fields and methods.
    private int currentTick;
    private STATUS status;
    private List<Pose> PoseList;

    public GPSIMU(int currentTick, STATUS status, List<Pose> PoseList){
        this.currentTick = currentTick;
        this.status = status;
        this.PoseList = PoseList;
    }
    // Getters
    public int getCurrentTick() {
        return currentTick;
    }

    public STATUS getStatus() {
        return status;
    }

    public List<Pose> getPoseList() {
        return PoseList;
    }
}

