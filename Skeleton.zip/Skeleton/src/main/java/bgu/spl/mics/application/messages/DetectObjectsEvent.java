package bgu.spl.mics.application.messages;
import bgu.spl.mics.Event;
import bgu.spl.mics.application.objects.DetectedObject;
import bgu.spl.mics.application.objects.StampedDetectedObjects;
import bgu.spl.mics.application.objects.TrackedObject;

import java.util.List;

public class DetectObjectsEvent implements Event<Boolean>{
    private StampedDetectedObjects detectedObjects;
    private int time;

    public DetectObjectsEvent(StampedDetectedObjects detectedObjects, int time) {
        this.detectedObjects = detectedObjects;
        this.time = time;
    }
    public StampedDetectedObjects getDetectedObjects() {
        return detectedObjects;
    }
    public int getTime() {
        return time;
    }

}
