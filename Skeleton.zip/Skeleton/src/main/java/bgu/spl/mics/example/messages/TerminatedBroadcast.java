package bgu.spl.mics.example.messages;

import bgu.spl.mics.Broadcast;

public class TerminatedBroadcast implements Broadcast {

}
