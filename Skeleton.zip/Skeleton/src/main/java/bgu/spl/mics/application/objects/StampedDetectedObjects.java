package bgu.spl.mics.application.objects;
import java.util.List;
/**
 * Represents objects detected by the camera at a specific timestamp.
 * Includes the time of detection and a list of detected objects.
 */
public class StampedDetectedObjects {
    private int time;
    private List<DetectedObject> DetectedObjects;

    public StampedDetectedObjects(int time, List<DetectedObject> DetectedObjects) {
        this.time = time;
        this.DetectedObjects = DetectedObjects;
    }
    // Getters
    public int getTime() {
        return time;
    }

    public List<DetectedObject> getDetectedObjects() {
        return DetectedObjects;
    }

    // Setters
    public void setTime(int time) {
        this.time = time;
    }

    public void setDetectedObjects(List<DetectedObject> DetectedObjects) {
        this.DetectedObjects = DetectedObjects;
    }
    // TODO: Define fields and methods.
}
