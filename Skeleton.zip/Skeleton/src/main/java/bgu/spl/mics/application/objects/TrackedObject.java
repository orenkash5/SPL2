package bgu.spl.mics.application.objects;

import java.util.List;

/**
 * Represents an object tracked by the LiDAR.
 * This object includes information about the tracked object's ID, description, 
 * time of tracking, and coordinates in the environment.
 */
public class TrackedObject {
    // TODO: Define fields and methods.
    private String id;
    private int time;
    private String description;
    private CloudPoint[] coordinates;

    public TrackedObject(String id, String description, int time, CloudPoint[] coordinates){
        this.id = id;
        this.description = description;
        this.time = time;
        this.coordinates = coordinates;
    }

}
