package bgu.spl.mics.application.objects;

import java.util.List;

/**
 * Represents a group of cloud points corresponding to a specific timestamp.
 * Used by the LiDAR system to store and process point cloud data for tracked objects.
 */
public class StampedCloudPoints {
    // TODO: Define fields and methods.
    private String id;
    private int time;
    private List<DetectedObject> cloudPoints;

    public StampedCloudPoints(int time, List<DetectedObject> cloudPoints){
        this.time = time;
        this.cloudPoints = cloudPoints;
    }

}
