package bgu.spl.mics.application.services;

import bgu.spl.mics.MicroService;
import bgu.spl.mics.application.messages.PoseEvent;
import bgu.spl.mics.application.messages.TickBroadcast;
import bgu.spl.mics.application.messages.TrackedObjectsEvent;
import bgu.spl.mics.application.objects.FusionSlam;
import bgu.spl.mics.application.objects.Pose;
import bgu.spl.mics.application.objects.TrackedObject;

import java.util.List;

/**
 * FusionSlamService integrates data from multiple sensors to build and update
 * the robot's global map.
 * <p>
 * This service receives TrackedObjectsEvents from LiDAR workers and PoseEvents from the PoseService,
 * transforming and updating the map with new landmarks.
 */
public class FusionSlamService extends MicroService {
    private FusionSlam fusionSlam;
    private int currentTime;

    //private StatisticalFolder stats;


    /**
     * Constructor for FusionSlamService.
     *
     * @param fusionSlam The FusionSLAM object responsible for managing the global map.
     */
    public FusionSlamService(FusionSlam fusionSlam) {
        super("FusionSlamService");
        // TODO Implement this
        this.fusionSlam = fusionSlam;
        this.currentTime = 0;
    }

    /**
     * Initializes the FusionSlamService.
     * Registers the service to handle TrackedObjectsEvents, PoseEvents, and TickBroadcasts,
     * and sets up callbacks for updating the global map.
     */
    @Override
    protected void initialize() {
        // TODO Implement this
        subscribeBroadcast(TickBroadcast.class, this::handleTick);
        subscribeEvent(TrackedObjectsEvent.class, this::handleTrackedObjects);
        subscribeEvent(PoseEvent.class, this::handlePose);
    }

    private void handleTick(TickBroadcast tick) {
        currentTime = tick.getCurrentTick();
    }

    private void handleTrackedObjects(TrackedObjectsEvent event) {
        List<TrackedObject> trackedObjects = event.getTrackedObjects();
        Pose[] poses = fusionSlam.getPoses();
        for (Pose p : poses) {
            if (p.getTime() == currentTime) {

                for (TrackedObject trackedObject : trackedObjects) {
                    //
                }
            }
        }
        complete(event, true);
    }
}
