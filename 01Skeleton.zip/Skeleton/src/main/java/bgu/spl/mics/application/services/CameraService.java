package bgu.spl.mics.application.services;

import bgu.spl.mics.MicroService;
import bgu.spl.mics.application.messages.CrashedBroadcast;
import bgu.spl.mics.application.messages.DetectObjectsEvent;
import bgu.spl.mics.application.messages.TerminatedBroadcast;
import bgu.spl.mics.application.messages.TickBroadcast;
import bgu.spl.mics.application.objects.Camera;
import bgu.spl.mics.application.objects.DetectedObject;
import bgu.spl.mics.application.objects.STATUS;
import bgu.spl.mics.application.objects.StatisticalFolder;

import java.util.List;

/**
 * CameraService is responsible for processing data from the camera and
 * sending DetectObjectsEvents to LiDAR workers.
 * 
 * This service interacts with the Camera object to detect objects and updates
 * the system's StatisticalFolder upon sending its observations.
 */
public class CameraService extends MicroService {
    private final Camera camera;
    private final StatisticalFolder statisticalFolder;

    /**
     * Constructor for CameraService.
     *
     * @param camera The Camera object that this service will use to detect objects.
     */

    public CameraService(Camera camera) {
        super("CameraService");
        this.camera=camera;
        this.statisticalFolder=StatisticalFolder.getInstance();
    }

    /**
     * Initializes the CameraService.
     * Registers the service to handle TickBroadcasts and sets up callbacks for sending
     * DetectObjectsEvents.
     */
    @Override
    protected void initialize() {
        subscribeBroadcast(TickBroadcast.class, this::handleTick);
        subscribeBroadcast(TerminatedBroadcast.class, broadcast -> terminate());
        subscribeBroadcast(CrashedBroadcast.class, broadcast -> terminate());
    }

    private void handleTick (TickBroadcast tick){
        int currentTick= tick.getCurrentTick();
        if (currentTick % camera.getFrequency() ==0){
            List<DetectedObject> detectedObjects= (camera.getDetectionsForTick(tick.getCurrentTick())).getDetectedObjects();
            if (detectedObjects!=null && !detectedObjects.isEmpty()){
                for(DetectedObject object: detectedObjects){
                    if (object.getId().equals("ERROR")){
                        sendBroadcast(new CrashedBroadcast());
                        camera.setStatus(STATUS.ERROR);
                        terminate();
                        return;
                    }

                    statisticalFolder.incrementNumDetectedObjects(detectedObjects.size());
                    sendEvent(new DetectObjectsEvent(detectedObjects, currentTick));

                }

            }
        }
    }
}
