package bgu.spl.mics.application.services;

import bgu.spl.mics.MicroService;
import bgu.spl.mics.application.messages.CrashedBroadcast;
import bgu.spl.mics.application.messages.DetectObjectsEvent;
import bgu.spl.mics.application.messages.TerminatedBroadcast;
import bgu.spl.mics.application.messages.TickBroadcast;
import bgu.spl.mics.application.objects.*;

import java.util.List;

/**
 * CameraService is responsible for processing data from the camera and
 * sending DetectObjectsEvents to LiDAR workers.
 * <p>
 * This service interacts with the Camera object to detect objects and updates
 * the system's StatisticalFolder upon sending its observations.
 */
public class CameraService extends MicroService {
    private final Camera camera;
    private final StatisticalFolder statisticalFolder;
    private final ServiceTracker serviceTracker;
    private final FusionSlam fusionSlam;

    /**
     * Constructor for CameraService.
     *
     * @param camera The Camera object that this service will use to detect objects.
     */

    public CameraService(Camera camera, FusionSlam fusionSlam) {
        super("CameraService");
        this.camera = camera;
        this.fusionSlam= fusionSlam;
        this.statisticalFolder = StatisticalFolder.getInstance();
        this.serviceTracker = ServiceTracker.getInstance();
    }

    public Camera getCamera() {
        return camera;
    }

    /**
     * Initializes the CameraService.
     * Registers the service to handle TickBroadcasts and sets up callbacks for sending
     * DetectObjectsEvents.
     */
    @Override
    protected void initialize() {
        subscribeBroadcast(TickBroadcast.class, this::handleTick);
        subscribeBroadcast(TerminatedBroadcast.class, broadcast -> terminate());
        subscribeBroadcast(CrashedBroadcast.class, broadcast -> terminate());
    }

    private void handleTick(TickBroadcast tick) {
        int currentTick = tick.getCurrentTick();
        if(currentTick > camera.getTimeOfLastDetection()){
            System.out.println("CameraService sending sensorTerminated. time: " + currentTick);
            fusionSlam.sensorTerminated();
            camera.setStatus(STATUS.DOWN);
            terminate();
            return;
        }
        for(StampedDetectedObjects stampedObject: camera.getDetectedObjectList()){
            if(stampedObject.getTime()>currentTick){
                return;
            }
            if(stampedObject.getTime()+ camera.getFrequency()==currentTick){
                List<DetectedObject> detectedObjects = stampedObject.getDetectedObjects();
                if (detectedObjects != null && !detectedObjects.isEmpty()) {
                    for (DetectedObject object : detectedObjects) {
                            if (object.getId().equals("ERROR")) {
                                System.out.println("CameraService sending CrashedBroadcast. time: " + stampedObject.getTime());
                                sendBroadcast(new CrashedBroadcast(object.getDescription(), camera.getCameraName()));
                                camera.setStatus(STATUS.ERROR);
                                terminate();
                                return;
                            }
                    }
                    camera.setLastDetectedObjects(stampedObject);
                    statisticalFolder.incrementNumDetectedObjects(detectedObjects.size());
                    System.out.println("cameraService send detectedObjectsEvent " + stampedObject.getTime());
                    sendEvent(new DetectObjectsEvent(stampedObject));
                    return;
                }
            }
        }
    }
}
